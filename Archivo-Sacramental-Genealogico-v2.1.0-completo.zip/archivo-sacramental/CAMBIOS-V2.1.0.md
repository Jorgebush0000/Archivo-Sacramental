# Archivo Sacramental y Genealógico — revisión 2.1.0

## Correcciones incorporadas

- Búsqueda avanzada por año aproximado con margen de ±5 años.
- El filtro de nombre busca tanto en la persona principal como en la segunda persona del registro matrimonial.
- El filtro de apellidos busca en los apellidos de ambas personas.
- Se conserva la búsqueda general sobre nombres, apellidos, familiares, parroquia, lugares, referencias, transcripción y notas.
- Se conserva el resto de funciones ya incluidas en la base 2.0: bautismos, matrimonios, defunciones, extractos/transcripciones literales, campos de filiación y abuelos, localización geográfica cubana y extranjera, catálogo de lugares, imágenes/adjuntos, estadísticas, certificaciones exportables PDF/JPG, papelera recuperable y copias de seguridad locales.
- Se conserva Electron + React + TypeScript + Vite + SQLite y el identificador existente de la aplicación, para que el programa siga usando la misma ubicación de datos del usuario al actualizar.

## Estructura de compilación

- `package.json`: scripts de desarrollo, compilación y empaquetado.
- `electron/`: proceso principal y puente seguro de Electron.
- `src/`: interfaz, lógica y datos administrativos de Cuba.
- `.github/workflows/build-windows.yml`: flujo de GitHub Actions para compilar la aplicación y publicar el instalador como artefacto.

## Nota de verificación

El ZIP se ha comprobado estructuralmente y se han revisado los cambios de búsqueda y la sintaxis del archivo de flujo. No se afirma que el instalador de Windows haya sido compilado aquí: la instalación de dependencias npm agotó el tiempo disponible en este entorno. La prueba final de compilación debe confirmarse en la ejecución de GitHub Actions.
