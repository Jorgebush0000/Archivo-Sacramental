# Archivo Sacramental y Genealógico — versión 2.1.0

Aplicación de escritorio para indexar, conservar y consultar libros sacramentales e históricos, con base de datos local. La versión 2.1.0 conserva las funciones de la versión 2.0 e integra las correcciones de búsqueda descritas a continuación.

## Mejoras de la versión 2.1.0

- **Búsqueda por persona en matrimonios corregida:** el filtro Nombre encuentra coincidencias en cualquiera de los dos contrayentes; el filtro Apellido busca entre los apellidos de ambos.
- **Año aproximado:** permite buscar por un año estimado con margen de cinco años antes y después (por ejemplo, 1880 busca de 1875 a 1885). Se combina con los demás filtros.
- **Versión de aplicación actualizada** a 2.1.0 sin cambiar el identificador de aplicación ni la ubicación de la base de datos local.

## Funciones incluidas en esta versión

- **Archivo:** subsecciones separadas para bautismos, matrimonios y defunciones.
- **Registro:** formularios de extracto y transcripción literal; los campos cambian según el tipo de partida.
- **Bautismos:** libro/tomo, folio, número, nombre del bautizado, fechas, padres y naturaleza, abuelos paternos y maternos, naturaleza de los abuelos y presbítero.
- **Matrimonios:** ambos contrayentes, filiación de ambos, naturaleza de los padres y celebrante.
- **Defunciones:** datos del difunto, nacimiento, entierro, edad, cónyuge, padres y celebrante.
- **Lugares de Cuba:** 15 provincias y selector de municipios; Isla de la Juventud aparece como municipio especial. También se puede marcar **Extranjero** y escribir libremente país, región y municipio, o introducir términos históricos.
- **Búsqueda:** búsqueda general y filtros combinables por nombre, apellidos, parroquia, localidad, país, provincia, municipio, tipo y fecha exacta o año/rango aproximado.
- **Estadísticas:** totales por tipo, imágenes, transcripciones, pendientes, provincia, municipio, país, parroquia y año.
- **Certificaciones:** modelos exportables en PDF y JPG desde cada partida.
- **Copias de seguridad:** exportación ZIP con la base SQLite, imágenes, documentos adjuntos e información de versión.
- **Trabajo local:** no requiere conexión a Internet para el trabajo ordinario.

## Tecnología

- Electron
- React + TypeScript + Vite
- SQLite mediante `better-sqlite3`
- `jsPDF` para documentos PDF y exportación de imágenes desde canvas
- `electron-builder` para el instalador de Windows

## Seguridad de los datos y actualización desde la versión 1

La aplicación conserva el mismo identificador de Electron y el mismo nombre de carpeta de datos de usuario. La base de datos se mantiene en `ArchivoSacramental/archivo.sqlite`; los adjuntos, en `ArchivoSacramental/adjuntos`. La inicialización de la versión 2 añade las columnas nuevas que faltan mediante migración no destructiva, sin eliminar las partidas previas.

**Antes de instalar una versión nueva, crea una copia desde la versión que tienes instalada.** No desinstales ni borres la carpeta de datos para actualizar. Aunque la migración está diseñada para preservar los datos, una copia externa es la protección más importante del archivo.

## Desarrollo local

Se recomienda Node.js 24. El proyecto se compila en Windows mediante GitHub Actions; la compilación produce un instalador `.exe` para Windows x64.

```bash
npm install
npm run dev
```

Para compilar la interfaz: `npm run build`. Para generar el instalador en Windows: `npm run dist:win`. El instalador aparecerá en `release/`.

## Generar el EXE desde GitHub Actions

El flujo está en `.github/workflows/build-windows.yml`; no requiere `cache: npm`, por lo que no depende de que exista un archivo lock para preparar Node.

1. Sube **el contenido** de esta carpeta al repositorio, conservando las rutas y ocultos como `.github/workflows/build-windows.yml`. No subas `node_modules`, `dist` ni `release`.
2. Abre la pestaña **Actions**.
3. Ejecuta **Crear instalador de Windows** mediante **Run workflow**, o haz un commit en `main`/`master`.
4. Cuando el flujo termine en verde, abre la ejecución y descarga el artefacto `Archivo-Sacramental-Instalador-Windows`.
5. Dentro estará el instalador `.exe`.

El ZIP de este repositorio contiene el código fuente; el archivo `.exe` se genera en la ejecución de GitHub Actions.

## Certificaciones

Los PDF/JPG son planillas documentales elaboradas a partir de la información guardada. La aplicación no concede por sí misma validez eclesiástica oficial; esa validez depende de la autoridad competente y de las firmas o sellos que correspondan.
