const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const Database = require('better-sqlite3');
const fs = require('node:fs');
const path = require('node:path');
const archiver = require('archiver');

let db;
let dataDir;
let attachmentDir;

function initDatabase() {
  dataDir = path.join(app.getPath('userData'), 'ArchivoSacramental');
  attachmentDir = path.join(dataDir, 'adjuntos');
  fs.mkdirSync(attachmentDir, { recursive: true });
  db = new Database(path.join(dataDir, 'archivo.sqlite'));
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.exec(`
    CREATE TABLE IF NOT EXISTS records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT NOT NULL DEFAULT 'bautismo',
      record_mode TEXT NOT NULL DEFAULT 'extracto',
      main_name TEXT NOT NULL DEFAULT '',
      main_surnames TEXT NOT NULL DEFAULT '',
      second_name TEXT NOT NULL DEFAULT '',
      second_surnames TEXT NOT NULL DEFAULT '',
      event_date TEXT NOT NULL DEFAULT '',
      birth_date TEXT NOT NULL DEFAULT '',
      burial_date TEXT NOT NULL DEFAULT '',
      father_name TEXT NOT NULL DEFAULT '',
      father_nature TEXT NOT NULL DEFAULT '',
      mother_name TEXT NOT NULL DEFAULT '',
      mother_nature TEXT NOT NULL DEFAULT '',
      paternal_grandfather_name TEXT NOT NULL DEFAULT '',
      paternal_grandmother_name TEXT NOT NULL DEFAULT '',
      paternal_grandparents_nature TEXT NOT NULL DEFAULT '',
      maternal_grandfather_name TEXT NOT NULL DEFAULT '',
      maternal_grandmother_name TEXT NOT NULL DEFAULT '',
      maternal_grandparents_nature TEXT NOT NULL DEFAULT '',
      priest TEXT NOT NULL DEFAULT '',
      second_father_name TEXT NOT NULL DEFAULT '',
      second_mother_name TEXT NOT NULL DEFAULT '',
      second_father_nature TEXT NOT NULL DEFAULT '',
      second_mother_nature TEXT NOT NULL DEFAULT '',
      spouse_name TEXT NOT NULL DEFAULT '',
      age TEXT NOT NULL DEFAULT '',
      parish TEXT NOT NULL DEFAULT '',
      city TEXT NOT NULL DEFAULT '',
      municipality TEXT NOT NULL DEFAULT '',
      province TEXT NOT NULL DEFAULT '',
      country TEXT NOT NULL DEFAULT '',
      volume TEXT NOT NULL DEFAULT '',
      folio TEXT NOT NULL DEFAULT '',
      record_number TEXT NOT NULL DEFAULT '',
      transcription TEXT NOT NULL DEFAULT '',
      notes TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'pendiente',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      deleted_at TEXT
    );
    CREATE TABLE IF NOT EXISTS catalog_entries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      kind TEXT NOT NULL,
      name TEXT NOT NULL,
      parent TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(kind, name COLLATE NOCASE, parent COLLATE NOCASE)
    );
    CREATE TABLE IF NOT EXISTS attachments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      record_id INTEGER NOT NULL,
      filename TEXT NOT NULL,
      original_name TEXT NOT NULL,
      mime_type TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(record_id) REFERENCES records(id)
    );
    CREATE INDEX IF NOT EXISTS idx_records_event_date ON records(event_date);
    CREATE INDEX IF NOT EXISTS idx_records_main_name ON records(main_name, main_surnames);
    CREATE INDEX IF NOT EXISTS idx_records_parish ON records(parish);
    CREATE INDEX IF NOT EXISTS idx_records_type ON records(type);
    CREATE INDEX IF NOT EXISTS idx_records_location ON records(country, province, municipality);
    CREATE INDEX IF NOT EXISTS idx_catalog_kind ON catalog_entries(kind);
    CREATE INDEX IF NOT EXISTS idx_attachments_record ON attachments(record_id);
  `);

  // Migración no destructiva: actualiza instalaciones v1 sin borrar sus partidas.
  const existing = new Set(db.pragma('table_info(records)').map(column => column.name));
  const additions = {
    record_mode: "TEXT NOT NULL DEFAULT 'extracto'",
    father_nature: "TEXT NOT NULL DEFAULT ''",
    mother_nature: "TEXT NOT NULL DEFAULT ''",
    paternal_grandfather_name: "TEXT NOT NULL DEFAULT ''",
    paternal_grandmother_name: "TEXT NOT NULL DEFAULT ''",
    paternal_grandparents_nature: "TEXT NOT NULL DEFAULT ''",
    maternal_grandfather_name: "TEXT NOT NULL DEFAULT ''",
    maternal_grandmother_name: "TEXT NOT NULL DEFAULT ''",
    maternal_grandparents_nature: "TEXT NOT NULL DEFAULT ''",
    priest: "TEXT NOT NULL DEFAULT ''",
    second_father_name: "TEXT NOT NULL DEFAULT ''",
    second_mother_name: "TEXT NOT NULL DEFAULT ''",
    second_father_nature: "TEXT NOT NULL DEFAULT ''",
    second_mother_nature: "TEXT NOT NULL DEFAULT ''"
  };
  for (const [column, definition] of Object.entries(additions)) {
    if (!existing.has(column)) db.exec(`ALTER TABLE records ADD COLUMN ${column} ${definition}`);
  }
  db.exec(`CREATE INDEX IF NOT EXISTS idx_records_location ON records(country, province, municipality)`);
}

const RECORD_FIELDS = [
  'type','record_mode','main_name','main_surnames','second_name','second_surnames','event_date','birth_date','burial_date',
  'father_name','father_nature','mother_name','mother_nature','paternal_grandfather_name','paternal_grandmother_name',
  'paternal_grandparents_nature','maternal_grandfather_name','maternal_grandmother_name','maternal_grandparents_nature',
  'priest','second_father_name','second_mother_name','second_father_nature','second_mother_nature','spouse_name','age',
  'parish','city','municipality','province','country','volume','folio','record_number','transcription','notes','status'
];

function safeRecordPayload(input) {
  const out = {};
  for (const key of RECORD_FIELDS) out[key] = String(input?.[key] ?? '').trim();
  out.type = ['bautismo','matrimonio','defuncion','confirmacion','comunion','exequias','otro'].includes(out.type) ? out.type : 'bautismo';
  out.record_mode = out.record_mode === 'literal' ? 'literal' : 'extracto';
  out.status = out.status === 'revisado' ? 'revisado' : 'pendiente';
  return out;
}

function addCatalogValue(kind, name, parent = '') {
  const cleanName = String(name || '').trim();
  const cleanParent = String(parent || '').trim();
  const accepted = ['parish','city','municipality','province','country'];
  if (!cleanName || !accepted.includes(kind)) return;
  db.prepare('INSERT OR IGNORE INTO catalog_entries (kind, name, parent) VALUES (?, ?, ?)').run(kind, cleanName, cleanParent);
}

function listRecords({ search = '', type = 'todos', limit = 1000, includeDeleted = false } = {}) {
  const term = `%${String(search).trim()}%`;
  const where = [includeDeleted ? '1=1' : 'deleted_at IS NULL'];
  const params = [];
  if (String(search).trim()) {
    where.push(`(
      main_name LIKE ? OR main_surnames LIKE ? OR second_name LIKE ? OR second_surnames LIKE ? OR
      father_name LIKE ? OR mother_name LIKE ? OR paternal_grandfather_name LIKE ? OR paternal_grandmother_name LIKE ? OR
      maternal_grandfather_name LIKE ? OR maternal_grandmother_name LIKE ? OR spouse_name LIKE ? OR priest LIKE ? OR parish LIKE ? OR city LIKE ? OR
      municipality LIKE ? OR province LIKE ? OR country LIKE ? OR volume LIKE ? OR folio LIKE ? OR record_number LIKE ? OR transcription LIKE ? OR notes LIKE ?
    )`);
    params.push(...Array(22).fill(term));
  }
  if (type && type !== 'todos') { where.push('type = ?'); params.push(type); }
  params.push(Math.max(1, Math.min(Number(limit) || 1000, 10000)));
  return db.prepare(`SELECT * FROM records WHERE ${where.join(' AND ')} ORDER BY updated_at DESC, id DESC LIMIT ?`).all(...params);
}

function rememberCatalogs(r) {
  addCatalogValue('parish', r.parish, r.city);
  addCatalogValue('city', r.city, r.municipality);
  addCatalogValue('municipality', r.municipality, r.province);
  addCatalogValue('province', r.province, r.country);
  addCatalogValue('country', r.country, '');
}

async function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 1080,
    minHeight: 700,
    backgroundColor: '#f4f2ed',
    title: 'Archivo Sacramental y Genealógico',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });
  if (process.env.VITE_DEV_SERVER_URL) await win.loadURL(process.env.VITE_DEV_SERVER_URL);
  else await win.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));
}

function registerIpc() {
  ipcMain.handle('records:list', (_e, opts) => listRecords(opts || {}));
  ipcMain.handle('records:get', (_e, id) => db.prepare('SELECT * FROM records WHERE id = ? AND deleted_at IS NULL').get(Number(id)) || null);
  ipcMain.handle('records:save', (_e, input) => {
    const r = safeRecordPayload(input);
    rememberCatalogs(r);
    if (input?.id) {
      const assignments = RECORD_FIELDS.map(field => `${field}=@${field}`).join(', ');
      db.prepare(`UPDATE records SET ${assignments}, updated_at=CURRENT_TIMESTAMP WHERE id=@id AND deleted_at IS NULL`).run({ ...r, id: Number(input.id) });
      return db.prepare('SELECT * FROM records WHERE id = ?').get(Number(input.id));
    }
    const columns = RECORD_FIELDS.join(', ');
    const values = RECORD_FIELDS.map(field => `@${field}`).join(', ');
    const result = db.prepare(`INSERT INTO records (${columns}) VALUES (${values})`).run(r);
    return db.prepare('SELECT * FROM records WHERE id = ?').get(Number(result.lastInsertRowid));
  });
  ipcMain.handle('records:search', (_e, filters = {}) => {
    const where = ['deleted_at IS NULL'];
    const params = [];
    const addLike = (column, value) => {
      const v = String(value ?? '').trim();
      if (v) { where.push(`${column} LIKE ? COLLATE NOCASE`); params.push(`%${v}%`); }
    };
    const personName = String(filters.name ?? '').trim();
    if (personName) {
      where.push('(main_name LIKE ? COLLATE NOCASE OR second_name LIKE ? COLLATE NOCASE)');
      params.push(`%${personName}%`, `%${personName}%`);
    }
    if (filters.surname) {
      where.push('(main_surnames LIKE ? COLLATE NOCASE OR second_surnames LIKE ? COLLATE NOCASE)');
      params.push(`%${String(filters.surname).trim()}%`, `%${String(filters.surname).trim()}%`);
    }
    addLike('parish', filters.parish);
    addLike('city', filters.city);
    addLike('country', filters.country);
    addLike('province', filters.province);
    addLike('municipality', filters.municipality);
    const any = String(filters.any ?? '').trim();
    if (any) {
      const columns = ['main_name','main_surnames','second_name','second_surnames','father_name','father_nature','mother_name','mother_nature','paternal_grandfather_name','paternal_grandmother_name','paternal_grandparents_nature','maternal_grandfather_name','maternal_grandmother_name','maternal_grandparents_nature','second_father_name','second_mother_name','spouse_name','priest','parish','city','municipality','province','country','volume','folio','record_number','transcription','notes'];
      where.push(`(${columns.map(column => `${column} LIKE ? COLLATE NOCASE`).join(' OR ')})`);
      params.push(...columns.map(() => `%${any}%`));
    }
    if (filters.type && filters.type !== 'todos') { where.push('type = ?'); params.push(String(filters.type)); }
    const exactDate = String(filters.exactDate ?? '').trim();
    if (/^\d{4}$/.test(exactDate)) { where.push('substr(event_date,1,4) = ?'); params.push(exactDate); }
    else if (exactDate) { where.push('event_date = ?'); params.push(exactDate); }
    const nearYear = Number.parseInt(String(filters.nearYear ?? ''), 10);
    if (Number.isFinite(nearYear) && nearYear >= 1000 && nearYear <= 9999) {
      where.push("CAST(substr(event_date,1,4) AS INTEGER) BETWEEN ? AND ?");
      params.push(Math.max(1000, nearYear - 5), Math.min(9999, nearYear + 5));
    }
    const fromYear = Number.parseInt(String(filters.fromYear ?? ''), 10);
    const toYear = Number.parseInt(String(filters.toYear ?? ''), 10);
    if (Number.isFinite(fromYear) && fromYear >= 1000 && fromYear <= 9999) { where.push("CAST(substr(event_date,1,4) AS INTEGER) >= ?"); params.push(fromYear); }
    if (Number.isFinite(toYear) && toYear >= 1000 && toYear <= 9999) { where.push("CAST(substr(event_date,1,4) AS INTEGER) <= ?"); params.push(toYear); }
    return db.prepare(`SELECT * FROM records WHERE ${where.join(' AND ')} ORDER BY event_date ASC, main_surnames COLLATE NOCASE, main_name COLLATE NOCASE LIMIT 10000`).all(...params);
  });
  ipcMain.handle('records:delete', (_e, id) => {
    db.prepare('UPDATE records SET deleted_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP WHERE id=?').run(Number(id));
    return { ok: true };
  });
  ipcMain.handle('records:restore', (_e, id) => {
    db.prepare('UPDATE records SET deleted_at=NULL, updated_at=CURRENT_TIMESTAMP WHERE id=?').run(Number(id));
    return { ok: true };
  });
  ipcMain.handle('records:trash', () => db.prepare('SELECT * FROM records WHERE deleted_at IS NOT NULL ORDER BY deleted_at DESC').all());
  ipcMain.handle('stats:get', () => {
    const total = db.prepare('SELECT COUNT(*) n FROM records WHERE deleted_at IS NULL').get().n;
    const byType = db.prepare('SELECT type, COUNT(*) n FROM records WHERE deleted_at IS NULL GROUP BY type').all();
    const withImages = db.prepare('SELECT COUNT(DISTINCT r.id) n FROM records r JOIN attachments a ON a.record_id=r.id WHERE r.deleted_at IS NULL').get().n;
    const pending = db.prepare("SELECT COUNT(*) n FROM records WHERE deleted_at IS NULL AND status='pendiente'").get().n;
    const withTranscription = db.prepare("SELECT COUNT(*) n FROM records WHERE deleted_at IS NULL AND trim(transcription)<>''").get().n;
    const recent = db.prepare('SELECT id, type, main_name, main_surnames, event_date, parish, updated_at FROM records WHERE deleted_at IS NULL ORDER BY updated_at DESC LIMIT 6').all();
    const byParish = db.prepare("SELECT COALESCE(NULLIF(parish,''),'Sin parroquia') name, COUNT(*) n FROM records WHERE deleted_at IS NULL GROUP BY parish ORDER BY n DESC LIMIT 6").all();
    const byYear = db.prepare("SELECT substr(event_date,1,4) year, COUNT(*) n FROM records WHERE deleted_at IS NULL AND substr(event_date,1,4) GLOB '[0-9][0-9][0-9][0-9]' GROUP BY year ORDER BY year DESC LIMIT 12").all().reverse();
    const byProvince = db.prepare("SELECT COALESCE(NULLIF(province,''),'Sin provincia') name, COUNT(*) n FROM records WHERE deleted_at IS NULL GROUP BY province ORDER BY n DESC LIMIT 12").all();
    const byMunicipality = db.prepare("SELECT COALESCE(NULLIF(municipality,''),'Sin municipio') name, COUNT(*) n FROM records WHERE deleted_at IS NULL GROUP BY municipality ORDER BY n DESC LIMIT 12").all();
    const byCountry = db.prepare("SELECT COALESCE(NULLIF(country,''),'Sin país') name, COUNT(*) n FROM records WHERE deleted_at IS NULL GROUP BY country ORDER BY n DESC LIMIT 12").all();
    return { total, byType, withImages, pending, withTranscription, recent, byParish, byYear, byProvince, byMunicipality, byCountry };
  });
  ipcMain.handle('catalog:list', (_e, kind = 'all') => {
    if (kind !== 'all') return db.prepare('SELECT * FROM catalog_entries WHERE kind=? ORDER BY name COLLATE NOCASE').all(kind);
    return db.prepare('SELECT * FROM catalog_entries ORDER BY kind, name COLLATE NOCASE').all();
  });
  ipcMain.handle('catalog:add', (_e, input) => {
    const kind = String(input?.kind || '');
    const name = String(input?.name || '').trim();
    const parent = String(input?.parent || '').trim();
    if (!name || !['parish','city','municipality','province','country'].includes(kind)) throw new Error('Introduce un nombre válido.');
    addCatalogValue(kind, name, parent);
    return db.prepare('SELECT * FROM catalog_entries WHERE kind=? AND name=? COLLATE NOCASE AND parent=? COLLATE NOCASE').get(kind, name, parent);
  });
  ipcMain.handle('attachments:list', (_e, recordId) => db.prepare('SELECT * FROM attachments WHERE record_id=? ORDER BY id DESC').all(Number(recordId)).map(a => {
    const filePath = path.join(attachmentDir, String(recordId), a.filename);
    let dataUrl;
    if (['image/jpeg', 'image/png', 'image/webp'].includes(a.mime_type) && fs.existsSync(filePath)) {
      const size = fs.statSync(filePath).size;
      if (size <= 12 * 1024 * 1024) dataUrl = `data:${a.mime_type};base64,${fs.readFileSync(filePath).toString('base64')}`;
    }
    return { ...a, path: filePath, dataUrl };
  }));
  ipcMain.handle('attachments:add', async (_e, recordId) => {
    const id = Number(recordId);
    const record = db.prepare('SELECT id FROM records WHERE id=? AND deleted_at IS NULL').get(id);
    if (!record) throw new Error('Guarda primero la partida antes de adjuntar imágenes.');
    const result = await dialog.showOpenDialog({
      title: 'Adjuntar imagen o documento a la partida',
      properties: ['openFile', 'multiSelections'],
      filters: [
        { name: 'Imágenes y documentos', extensions: ['jpg','jpeg','png','webp','pdf','tif','tiff'] },
        { name: 'Todos los archivos', extensions: ['*'] }
      ]
    });
    if (result.canceled || !result.filePaths.length) return [];
    const folder = path.join(attachmentDir, String(id));
    fs.mkdirSync(folder, { recursive: true });
    const insert = db.prepare('INSERT INTO attachments (record_id, filename, original_name, mime_type) VALUES (?, ?, ?, ?)');
    const added = [];
    for (const source of result.filePaths) {
      const original = path.basename(source);
      const ext = path.extname(original);
      const filename = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}${ext}`;
      const target = path.join(folder, filename);
      fs.copyFileSync(source, target);
      const extension = ext.toLowerCase();
      const mime = extension === '.pdf' ? 'application/pdf' :
        ['.jpg', '.jpeg'].includes(extension) ? 'image/jpeg' :
        extension === '.png' ? 'image/png' : extension === '.webp' ? 'image/webp' :
        ['.tif', '.tiff'].includes(extension) ? 'image/tiff' : 'application/octet-stream';
      const res = insert.run(id, filename, original, mime);
      added.push({ id: Number(res.lastInsertRowid), record_id: id, filename, original_name: original, mime_type: mime, path: target });
    }
    return added;
  });
  ipcMain.handle('attachments:open', async (_e, filePath) => {
    const resolved = path.resolve(String(filePath || ''));
    if (!resolved.startsWith(path.resolve(attachmentDir) + path.sep)) throw new Error('Ruta de archivo no permitida.');
    const err = await shell.openPath(resolved);
    if (err) throw new Error(err);
    return { ok: true };
  });
  ipcMain.handle('backup:create', async () => {
    const save = await dialog.showSaveDialog({
      title: 'Crear copia de seguridad',
      defaultPath: path.join(app.getPath('documents'), `Archivo-Sacramental-respaldo-${new Date().toISOString().slice(0,10)}.zip`),
      filters: [{ name: 'Copia de seguridad ZIP', extensions: ['zip'] }]
    });
    if (save.canceled || !save.filePath) return { canceled: true };
    db.pragma('wal_checkpoint(FULL)');
    return new Promise((resolve, reject) => {
      const output = fs.createWriteStream(save.filePath);
      const archive = archiver('zip', { zlib: { level: 8 } });
      output.on('close', () => resolve({ ok: true, path: save.filePath, bytes: archive.pointer() }));
      archive.on('error', reject);
      archive.pipe(output);
      archive.file(path.join(dataDir, 'archivo.sqlite'), { name: 'archivo.sqlite' });
      if (fs.existsSync(attachmentDir)) archive.directory(attachmentDir, 'adjuntos');
      archive.append(JSON.stringify({ app: 'Archivo Sacramental y Genealógico', version: app.getVersion(), createdAt: new Date().toISOString() }, null, 2), { name: 'respaldo-info.json' });
      archive.finalize();
    });
  });
  ipcMain.handle('app:info', () => ({ version: app.getVersion(), dataDir, attachmentDir, platform: process.platform }));
  ipcMain.handle('app:showDataFolder', () => shell.openPath(dataDir));
}

app.whenReady().then(() => {
  initDatabase();
  registerIpc();
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('before-quit', () => { if (db) { try { db.close(); } catch {} } });
