const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('archiveApi', {
  listRecords: (options) => ipcRenderer.invoke('records:list', options),
  searchRecords: (filters) => ipcRenderer.invoke('records:search', filters),
  getRecord: (id) => ipcRenderer.invoke('records:get', id),
  saveRecord: (record) => ipcRenderer.invoke('records:save', record),
  deleteRecord: (id) => ipcRenderer.invoke('records:delete', id),
  restoreRecord: (id) => ipcRenderer.invoke('records:restore', id),
  listTrash: () => ipcRenderer.invoke('records:trash'),
  getStats: () => ipcRenderer.invoke('stats:get'),
  listCatalog: (kind) => ipcRenderer.invoke('catalog:list', kind),
  addCatalog: (entry) => ipcRenderer.invoke('catalog:add', entry),
  listAttachments: (recordId) => ipcRenderer.invoke('attachments:list', recordId),
  addAttachments: (recordId) => ipcRenderer.invoke('attachments:add', recordId),
  openAttachment: (filePath) => ipcRenderer.invoke('attachments:open', filePath),
  createBackup: () => ipcRenderer.invoke('backup:create'),
  getAppInfo: () => ipcRenderer.invoke('app:info'),
  showDataFolder: () => ipcRenderer.invoke('app:showDataFolder')
});
