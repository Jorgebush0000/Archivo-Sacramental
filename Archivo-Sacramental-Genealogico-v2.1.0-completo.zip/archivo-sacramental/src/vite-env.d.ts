/// <reference types="vite/client" />

interface ArchiveRecord {
  id?: number;
  type: string;
  record_mode: string;
  main_name: string;
  main_surnames: string;
  second_name: string;
  second_surnames: string;
  event_date: string;
  birth_date: string;
  burial_date: string;
  father_name: string;
  father_nature: string;
  mother_name: string;
  mother_nature: string;
  paternal_grandfather_name: string;
  paternal_grandmother_name: string;
  paternal_grandparents_nature: string;
  maternal_grandfather_name: string;
  maternal_grandmother_name: string;
  maternal_grandparents_nature: string;
  priest: string;
  second_father_name: string;
  second_mother_name: string;
  second_father_nature: string;
  second_mother_nature: string;
  spouse_name: string;
  age: string;
  parish: string;
  city: string;
  municipality: string;
  province: string;
  country: string;
  volume: string;
  folio: string;
  record_number: string;
  transcription: string;
  notes: string;
  status: string;
  created_at?: string;
  updated_at?: string;
  deleted_at?: string | null;
}

interface ArchiveCatalog {
  id: number;
  kind: string;
  name: string;
  parent: string;
  created_at: string;
}

interface ArchiveAttachment {
  id: number;
  record_id: number;
  filename: string;
  original_name: string;
  mime_type: string;
  path: string;
  dataUrl?: string;
}

interface ArchiveStats {
  total: number;
  byType: { type: string; n: number }[];
  withImages: number;
  pending: number;
  withTranscription: number;
  byProvince: { name: string; n: number }[];
  byMunicipality: { name: string; n: number }[];
  byCountry: { name: string; n: number }[];
  recent: ArchiveRecord[];
  byParish: { name: string; n: number }[];
  byYear: { year: string; n: number }[];
}

interface Window {
  archiveApi: {
    listRecords: (options?: { search?: string; type?: string; limit?: number; includeDeleted?: boolean }) => Promise<ArchiveRecord[]>;
    searchRecords: (filters?: { any?: string; name?: string; surname?: string; parish?: string; city?: string; country?: string; province?: string; municipality?: string; type?: string; exactDate?: string; fromYear?: string; toYear?: string }) => Promise<ArchiveRecord[]>;
    getRecord: (id: number) => Promise<ArchiveRecord | null>;
    saveRecord: (record: ArchiveRecord) => Promise<ArchiveRecord>;
    deleteRecord: (id: number) => Promise<{ok: boolean}>;
    restoreRecord: (id: number) => Promise<{ok: boolean}>;
    listTrash: () => Promise<ArchiveRecord[]>;
    getStats: () => Promise<ArchiveStats>;
    listCatalog: (kind?: string) => Promise<ArchiveCatalog[]>;
    addCatalog: (entry: {kind: string; name: string; parent?: string}) => Promise<ArchiveCatalog>;
    listAttachments: (recordId: number) => Promise<ArchiveAttachment[]>;
    addAttachments: (recordId: number) => Promise<ArchiveAttachment[]>;
    openAttachment: (path: string) => Promise<{ok: boolean}>;
    createBackup: () => Promise<{ok?: boolean; canceled?: boolean; path?: string; bytes?: number}>;
    getAppInfo: () => Promise<{version: string; dataDir: string; attachmentDir: string; platform: string}>;
    showDataFolder: () => Promise<unknown>;
  };
}
