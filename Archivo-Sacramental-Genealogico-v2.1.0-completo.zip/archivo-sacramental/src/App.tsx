import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { jsPDF } from 'jspdf';
import {
  Archive, BookOpen, Search, LayoutDashboard, FilePlus2, Files, Users, MapPin,
  FileCheck2, ShieldCheck, Settings2, ChevronRight, Plus, Filter, Download,
  Image as ImageIcon, Pencil, Trash2, Eye, X, Check, AlertCircle, Clock3,
  BookMarked, HeartHandshake, Landmark, CalendarDays, FolderOpen, ExternalLink,
  RotateCcw, FileText, ArrowUpRight, ChevronDown, Save, Sparkles, ClipboardList
} from 'lucide-react';
import { CUBA_ADMIN, CUBA_PROVINCES, CUBA_MUNICIPALITY_COUNT, CUBA_SPECIAL_MUNICIPALITY } from './cuba';

type Page = 'archivo' | 'registro' | 'busqueda' | 'estadisticas';
const TYPE_LABELS: Record<string, string> = {
  bautismo: 'Bautismo', matrimonio: 'Matrimonio', defuncion: 'Defunción',
  confirmacion: 'Confirmación', comunion: 'Primera comunión', exequias: 'Exequias', otro: 'Otro'
};
const TYPE_OPTIONS = ['bautismo','matrimonio','defuncion'].map(value => ({ value, label: TYPE_LABELS[value] }));
const CATALOG_LABELS: Record<string, string> = {
  parish: 'Parroquia', city: 'Ciudad o localidad', municipality: 'Municipio', province: 'Provincia o región', country: 'País'
};
const DEFAULT_RECORD: ArchiveRecord = {
  type: 'bautismo', record_mode: 'extracto', main_name: '', main_surnames: '', second_name: '', second_surnames: '',
  event_date: '', birth_date: '', burial_date: '', father_name: '', father_nature: '', mother_name: '', mother_nature: '',
  paternal_grandfather_name: '', paternal_grandmother_name: '', paternal_grandparents_nature: '',
  maternal_grandfather_name: '', maternal_grandmother_name: '', maternal_grandparents_nature: '', priest: '',
  second_father_name: '', second_mother_name: '', second_father_nature: '', second_mother_nature: '',
  spouse_name: '', age: '', parish: '', city: '', municipality: '', province: '', country: 'Cuba',
  volume: '', folio: '', record_number: '', transcription: '', notes: '', status: 'pendiente'
};
const dateLabel = (value?: string) => {
  if (!value) return '—';
  const [y, m, d] = value.split('-');
  return y && m && d ? `${d}/${m}/${y}` : value;
};
const fullName = (r: Partial<ArchiveRecord>) => [r.main_name, r.main_surnames].filter(Boolean).join(' ').trim() || 'Sin nombre';
const reference = (r: Partial<ArchiveRecord>) => [r.volume ? `T. ${r.volume}` : '', r.folio ? `F. ${r.folio}` : '', r.record_number ? `N.º ${r.record_number}` : ''].filter(Boolean).join(' · ') || 'Sin referencia';
const emptyStats: ArchiveStats = { total: 0, byType: [], withImages: 0, pending: 0, withTranscription: 0, byProvince: [], byMunicipality: [], byCountry: [], recent: [], byParish: [], byYear: [] };

function App() {
  const [page, setPage] = useState<Page>('archivo');
  const [archiveType, setArchiveType] = useState('bautismo');
  const [quickSearch, setQuickSearch] = useState('');
  const [records, setRecords] = useState<ArchiveRecord[]>([]);
  const [stats, setStats] = useState<ArchiveStats>(emptyStats);
  const [catalog, setCatalog] = useState<ArchiveCatalog[]>([]);
  const [loading, setLoading] = useState(true);
  const [editorOpen, setEditorOpen] = useState(false);
  const [editRecord, setEditRecord] = useState<ArchiveRecord | null>(null);
  const [registerType, setRegisterType] = useState('bautismo');
  const [registerMode, setRegisterMode] = useState<'extracto'|'literal'>('extracto');
  const [notice, setNotice] = useState<{kind: 'success' | 'error' | 'info'; text: string} | null>(null);
  const [trashOpen, setTrashOpen] = useState(false);
  const [trash, setTrash] = useState<ArchiveRecord[]>([]);
  const [appInfo, setAppInfo] = useState<{version: string; dataDir: string; attachmentDir: string; platform: string} | null>(null);
  const [certificateRecord, setCertificateRecord] = useState<ArchiveRecord | null>(null);
  const [backupBusy, setBackupBusy] = useState(false);

  const refresh = useCallback(async () => {
    try {
      const [r, s, c, info] = await Promise.all([
        window.archiveApi.listRecords({ search: '', type: page === 'archivo' ? archiveType : 'todos', limit: 5000 }),
        window.archiveApi.getStats(), window.archiveApi.listCatalog(), window.archiveApi.getAppInfo()
      ]);
      setRecords(r); setStats(s); setCatalog(c); setAppInfo(info);
    } catch (e) {
      setNotice({ kind: 'error', text: `No se pudo leer la base de datos local: ${String(e)}` });
    } finally { setLoading(false); }
  }, [page, archiveType]);

  useEffect(() => { void refresh(); }, [refresh]);
  useEffect(() => {
    if (!notice) return;
    const t = window.setTimeout(() => setNotice(null), 5000);
    return () => window.clearTimeout(t);
  }, [notice]);

  const openNew = (mode: 'extracto'|'literal' = 'extracto', type = registerType) => {
    setPage('registro'); setRegisterType(type); setRegisterMode(mode);
    setEditRecord({ ...DEFAULT_RECORD, type, record_mode: mode, country: 'Cuba' });
    setEditorOpen(true);
  };
  const openEdit = (r: ArchiveRecord) => {
    const mode = r.record_mode === 'literal' ? 'literal' : 'extracto';
    setRegisterType(r.type || 'bautismo'); setRegisterMode(mode);
    setEditRecord({ ...DEFAULT_RECORD, ...r, record_mode: mode });
    setPage('registro'); setEditorOpen(true);
  };
  const afterSave = async (r: ArchiveRecord, next: boolean) => {
    setNotice({ kind: 'success', text: `Partida ${r.id ? `n.º ${r.id} ` : ''}guardada correctamente en la base de datos local.` });
    await refresh();
    if (next) {
      setEditRecord({ ...DEFAULT_RECORD, type: r.type, record_mode: registerMode, parish: r.parish, city: r.city, municipality: r.municipality, province: r.province, country: r.country, volume: r.volume, status: 'pendiente' });
      setEditorOpen(true);
    } else setEditorOpen(false);
  };
  const closeEditor = () => { setEditorOpen(false); void refresh(); };
  const removeRecord = async (r: ArchiveRecord) => {
    if (!r.id || !window.confirm(`¿Enviar a la papelera la partida de ${fullName(r)}? Puedes recuperarla después.`)) return;
    try { await window.archiveApi.deleteRecord(r.id); setNotice({ kind: 'success', text: 'Partida movida a la papelera.' }); await refresh(); }
    catch (e) { setNotice({ kind: 'error', text: `No se pudo mover la partida a la papelera: ${String(e)}` }); }
  };
  const makeBackup = async () => {
    setBackupBusy(true);
    try {
      const result = await window.archiveApi.createBackup();
      if (result.canceled) return;
      if (result.ok) setNotice({ kind: 'success', text: `Copia completa exportada: ${result.path}` });
    } catch (e) { setNotice({ kind: 'error', text: `No se pudo exportar la copia: ${String(e)}` }); }
    finally { setBackupBusy(false); }
  };
  const navItems = [
    { id: 'archivo' as Page, label: 'Archivo', icon: Archive, detail: `${stats.total.toLocaleString('es-ES')} partidas` },
    { id: 'registro' as Page, label: 'Registro', icon: FilePlus2, detail: 'Crear partidas' },
    { id: 'busqueda' as Page, label: 'Búsqueda', icon: Search, detail: 'Buscar en el índice' },
    { id: 'estadisticas' as Page, label: 'Estadísticas', icon: LayoutDashboard, detail: 'Resumen del archivo' }
  ];
  const titles: Record<Page, {title:string;subtitle:string}> = {
    archivo: { title: 'Archivo sacramental', subtitle: 'Consulta las partidas por tipo de libro y abre su ficha documental.' },
    registro: { title: editorOpen ? (editRecord?.id ? 'Editar registro' : 'Nuevo registro') : 'Registrar una partida', subtitle: 'Elige el formulario de extracto para indexar datos o el literal para transcribir el documento.' },
    busqueda: { title: 'Búsqueda documental', subtitle: 'Combina nombre, apellidos, parroquia, lugar y fechas para localizar partidas.' },
    estadisticas: { title: 'Estadísticas del archivo', subtitle: 'Consulta las cifras y distribuciones de todos los registros guardados.' }
  };
  const current = titles[page];
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand-lockup">
        <div className="brand-mark"><Landmark size={24} strokeWidth={1.7} /></div>
        <div><div className="brand-name">Archivo Sacramental</div><div className="brand-sub">Y GENEALÓGICO</div><div className="brand-edition">EDICIÓN DE ESCRITORIO</div></div>
      </div>
      <div className="workspace-label">ARCHIVO DOCUMENTAL</div>
      <div className="sidebar-promise"><BookMarked size={22}/><strong>Tu archivo, bajo tu control</strong><p>Las partidas, las imágenes y las copias de seguridad permanecen en este equipo. No se necesita conexión a Internet.</p></div>
      <div className="sidebar-spacer" />
      <div className="sidebar-tip"><div className="tip-icon"><ShieldCheck size={16} /></div><strong>Conserva tu trabajo</strong><p>Exporta una copia con la base de datos y todos los adjuntos.</p><button onClick={() => void makeBackup()} disabled={backupBusy}>{backupBusy ? 'Preparando copia…' : 'Exportar copia ahora'} <ChevronRight size={14}/></button></div>
      <div className="sidebar-footer"><span className="status-dot"/> Base de datos local <span className="version">v{appInfo?.version || '2.1.0'}</span></div>
    </aside>

    <main className="main-area">
      <nav className="primary-section-nav" aria-label="Secciones principales">
        {navItems.map(item => { const Icon = item.icon; return <button key={item.id} className={`primary-tab ${page === item.id ? 'active' : ''}`} onClick={() => setPage(item.id)}><Icon size={18}/><span><strong>{item.label}</strong><small>{item.detail}</small></span>{page === item.id && <i/>}</button>; })}
      </nav>
      <header className="topbar">
        <div className="breadcrumb"><span>Archivo Sacramental</span><ChevronRight size={14}/><strong>{current.title}</strong></div>
        <div className="topbar-actions">
          <label className="global-search"><Search size={17}/><input aria-label="Búsqueda rápida" placeholder="Búsqueda rápida por nombre o partida…" value={quickSearch} onChange={e => { setQuickSearch(e.target.value); if (e.target.value) setPage('busqueda'); }}/><kbd>Buscar</kbd></label>
          <button className="secondary-button top-backup" onClick={() => void makeBackup()} disabled={backupBusy}><ShieldCheck size={15}/>{backupBusy ? 'Exportando…' : 'Exportar copia'}</button>
          <button className="primary-button top-new" onClick={() => openNew('extracto', page === 'archivo' ? archiveType : registerType)}><Plus size={17}/> Nuevo registro</button>
        </div>
      </header>
      <div className="page-body">
        <div className="page-heading"><div><div className="eyebrow">ARCHIVO SACRAMENTAL Y GENEALÓGICO · VERSIÓN 2.0</div><h1>{current.title}</h1><p>{current.subtitle}</p></div>
          {page === 'archivo' && <button className="primary-button" onClick={() => openNew('extracto', archiveType)}><Plus size={16}/> Registrar partida</button>}
        </div>
        {page === 'archivo' && <ArchivePage records={records} activeType={archiveType} setActiveType={setArchiveType} loading={loading} openNew={(type) => openNew('extracto', type)} openEdit={openEdit} removeRecord={removeRecord} onCertify={setCertificateRecord} openTrash={async () => { try { setTrash(await window.archiveApi.listTrash()); setTrashOpen(true); } catch(e) { setNotice({kind:'error',text:String(e)}); } }} />}
        {page === 'registro' && (editorOpen && editRecord
          ? <RecordEditor key={`${editRecord.id || 'new'}-${editRecord.record_mode}-${editRecord.type}`} record={editRecord} catalog={catalog} standalone initialMode={registerMode} onClose={closeEditor} onSave={afterSave} notify={setNotice}/>
          : <RegistrationLanding selectedType={registerType} setSelectedType={setRegisterType} onChoose={(mode) => openNew(mode, registerType)} />)}
        {page === 'busqueda' && <AdvancedSearchPage quickSearch={quickSearch} onEdit={openEdit} onCertify={setCertificateRecord} notify={setNotice} />}
        {page === 'estadisticas' && <StatisticsPage stats={stats} />}
      </div>
    </main>
    {certificateRecord && <div className="modal-scrim certification-scrim" onMouseDown={e=>{if(e.target===e.currentTarget)setCertificateRecord(null);}}><section className="certification-modal"><header><div><div className="eyebrow">EMISIÓN DE DOCUMENTOS</div><h2>Certificación de partida</h2><p>Previsualiza el extracto y exporta la planilla en PDF o JPG.</p></div><button className="icon-button" onClick={()=>setCertificateRecord(null)} aria-label="Cerrar certificación"><X size={18}/></button></header><CertificatesPage records={[certificateRecord]} initialSelected={certificateRecord.id || ''} notify={setNotice}/></section></div>}
    {trashOpen && <TrashModal items={trash} onClose={() => setTrashOpen(false)} onRestore={async (r) => { if (r.id) await window.archiveApi.restoreRecord(r.id); setTrash(await window.archiveApi.listTrash()); await refresh(); setNotice({kind:'success', text:'Partida restaurada.'}); }} />}
    {notice && <div className={`toast ${notice.kind}`}><span className="toast-symbol">{notice.kind === 'success' ? <Check size={17}/> : notice.kind === 'error' ? <AlertCircle size={17}/> : <Clock3 size={17}/>}</span>{notice.text}<button onClick={() => setNotice(null)} aria-label="Cerrar aviso"><X size={15}/></button></div>}
  </div>;
}

function Dashboard({ stats, records, openNew, goRecords, openRecord, onBackup }: {stats: ArchiveStats; records: ArchiveRecord[]; openNew: () => void; goRecords: () => void; openRecord: (r: ArchiveRecord) => void; onBackup: () => void}) {
  const typeCount = (type: string) => stats.byType.find(x => x.type === type)?.n || 0;
  const maxParish = Math.max(1, ...stats.byParish.map(x => x.n));
  const maxYear = Math.max(1, ...stats.byYear.map(x => x.n));
  return <>
    <div className="welcome-banner"><div className="welcome-copy"><div className="banner-kicker"><span/> TU ARCHIVO, A TU RITMO</div><h2>La memoria de cada familia<br/>merece ser preservada.</h2><p>Indexa partidas, conserva las fuentes originales y encuentra información con rapidez.</p><div className="banner-buttons"><button className="banner-button" onClick={openNew}><FilePlus2 size={17}/> Añadir una partida <ChevronRight size={15}/></button><button className="banner-link" onClick={goRecords}>Explorar el archivo <ArrowUpRight size={15}/></button></div></div><div className="banner-art" aria-hidden="true"><div className="art-circle circle-one"/><div className="art-circle circle-two"/><div className="art-document"><div className="art-seal"><BookMarked size={31}/></div><div className="art-rule wide"/><div className="art-rule"/><div className="art-rule short"/><div className="art-rule mid"/><div className="art-signature"/></div><div className="art-leaf leaf-a"/><div className="art-leaf leaf-b"/></div></div>
    <div className="stats-grid">
      <StatCard label="REGISTROS INDEXADOS" value={stats.total.toLocaleString('es-ES')} detail="Partidas en el archivo" icon={<Files size={18}/>} tone="navy" />
      <StatCard label="BAUTISMOS" value={typeCount('bautismo').toLocaleString('es-ES')} detail="Registros sacramentales" icon={<BookOpen size={18}/>} tone="gold" />
      <StatCard label="CON IMÁGENES" value={stats.withImages.toLocaleString('es-ES')} detail="Con fuente adjunta" icon={<ImageIcon size={18}/>} tone="green" />
      <StatCard label="POR REVISAR" value={stats.pending.toLocaleString('es-ES')} detail="Marcados como pendientes" icon={<ClipboardList size={18}/>} tone="violet" />
    </div>
    <div className="dashboard-columns">
      <section className="panel recent-panel"><div className="panel-heading"><div><h3>Últimas partidas</h3><p>Registros añadidos o modificados recientemente</p></div><button className="text-button" onClick={goRecords}>Ver archivo <ChevronRight size={15}/></button></div>
        {stats.recent.length === 0 ? <EmptyState icon={<BookOpen size={25}/>} title="Tu archivo comienza aquí" text="Añade la primera partida para empezar a construir tu índice histórico." action={<button className="primary-button" onClick={openNew}><Plus size={16}/> Crear primera partida</button>} /> : <div className="recent-list">{stats.recent.map(r => <button className="recent-row" key={r.id} onClick={() => openRecord(r)}><div className={`record-type-icon ${r.type}`}><BookMarked size={17}/></div><div className="recent-main"><strong>{fullName(r)}</strong><span>{TYPE_LABELS[r.type] || 'Otro registro'} · {r.parish || 'Parroquia sin indicar'}</span></div><div className="recent-date">{dateLabel(r.event_date)}</div><ChevronRight size={16} className="muted-chevron"/></button>)}</div>}
      </section>
      <section className="panel parish-panel"><div className="panel-heading"><div><h3>Registros por parroquia</h3><p>Dónde se concentra tu archivo</p></div><MapPin size={19} className="panel-heading-icon"/></div>
        {stats.byParish.length === 0 ? <EmptyMini text="Las parroquias aparecerán al guardar partidas."/> : <div className="bar-list">{stats.byParish.map((p, i) => <div className="bar-row" key={p.name}><div className="bar-caption"><span>{p.name}</span><b>{p.n}</b></div><div className="bar-track"><div className={`bar-fill bar-${i%4}`} style={{width:`${Math.max(3, p.n / maxParish * 100)}%`}}/></div></div>)}</div>}
        <div className="panel-footnote"><Landmark size={15}/> Los lugares se guardan a medida que indexas.</div>
        <div className="year-chart"><div className="year-chart-heading"><strong>Registros por año</strong><span>Según la fecha del acto</span></div>{stats.byYear.length ? <div className="year-bars">{stats.byYear.map(y=><div className="year-bar-col" key={y.year} title={`${y.year}: ${y.n} registro(s)`}><span>{y.n}</span><div><i style={{height:`${Math.max(4,y.n/maxYear*100)}%`}}/></div><small>{y.year}</small></div>)}</div> : <div className="year-empty">Los años aparecerán cuando introduzcas fechas.</div>}</div>
      </section>
    </div>
    <div className="quick-actions"><div><div className="eyebrow">ACCESOS RÁPIDOS</div><h3>¿Qué necesitas hacer?</h3></div><QuickAction icon={<FilePlus2 size={19}/>} title="Indexar una partida" text="Crear un nuevo registro" onClick={openNew}/><QuickAction icon={<Search size={19}/>} title="Buscar información" text="Consultar partidas existentes" onClick={goRecords}/><QuickAction icon={<ShieldCheck size={19}/>} title="Crear una copia" text="Proteger tu trabajo" onClick={onBackup}/></div>
  </>;
}

function StatCard({label,value,detail,icon,tone}:{label:string;value:string;detail:string;icon:React.ReactNode;tone:string}) { return <div className="stat-card"><div className={`stat-icon ${tone}`}>{icon}</div><div className="stat-label">{label}</div><div className="stat-value">{value}</div><div className="stat-detail">{detail}</div></div>; }
function QuickAction({icon,title,text,onClick}:{icon:React.ReactNode;title:string;text:string;onClick:()=>void}) { return <button className="quick-action" onClick={onClick}><span className="quick-icon">{icon}</span><span><strong>{title}</strong><small>{text}</small></span><ChevronRight size={17}/></button>; }
function EmptyState({icon,title,text,action}:{icon:React.ReactNode;title:string;text:string;action?:React.ReactNode}) { return <div className="empty-state"><div className="empty-icon">{icon}</div><h3>{title}</h3><p>{text}</p>{action}</div>; }
function EmptyMini({text}:{text:string}) { return <div className="empty-mini">{text}</div>; }

function ArchivePage({records,activeType,setActiveType,loading,openNew,openEdit,removeRecord,onCertify,openTrash}:{records:ArchiveRecord[];activeType:string;setActiveType:(v:string)=>void;loading:boolean;openNew:(type:string)=>void;openEdit:(r:ArchiveRecord)=>void;removeRecord:(r:ArchiveRecord)=>void;onCertify:(r:ArchiveRecord)=>void;openTrash:()=>void}) {
  const sections = [
    {id:'bautismo',label:'Bautismos',desc:'Libros de bautizados',icon:BookOpen},
    {id:'matrimonio',label:'Matrimonios',desc:'Libros matrimoniales',icon:HeartHandshake},
    {id:'defuncion',label:'Defunciones',desc:'Libros de defunción',icon:BookMarked}
  ];
  return <>
    <div className="archive-subnav">{sections.map(item=>{const Icon=item.icon;return <button key={item.id} onClick={()=>setActiveType(item.id)} className={`archive-subtab ${activeType===item.id?'active':''}`}><span className="archive-subtab-icon"><Icon size={19}/></span><span><strong>{item.label}</strong><small>{item.desc}</small></span><span className="archive-subtab-count">{activeType===item.id?records.length.toLocaleString('es-ES'):'›'}</span></button>;})}</div>
    <RecordsPage records={records} activeType={activeType} loading={loading} openNew={()=>openNew(activeType)} openEdit={openEdit} removeRecord={removeRecord} onCertify={onCertify} openTrash={openTrash}/>
  </>;
}

function RecordsPage({records,activeType,loading,openNew,openEdit,removeRecord,onCertify,openTrash}:{records:ArchiveRecord[];activeType:string;loading:boolean;openNew:()=>void;openEdit:(r:ArchiveRecord)=>void;removeRecord:(r:ArchiveRecord)=>void;onCertify:(r:ArchiveRecord)=>void;openTrash:()=>void}) {
  const [statusOnly, setStatusOnly] = useState('todos');
  const shown = records.filter(r => statusOnly === 'todos' || r.status === statusOnly);
  return <section className="panel table-panel"><div className="table-toolbar"><div className="results-count"><strong>{shown.length.toLocaleString('es-ES')}</strong> {TYPE_LABELS[activeType]?.toLocaleLowerCase() || 'partidas'} encontradas</div><div className="table-tools"><label className="filter-select"><Filter size={15}/><select value={statusOnly} onChange={e => setStatusOnly(e.target.value)}><option value="todos">Todos los estados</option><option value="pendiente">Pendientes de revisión</option><option value="revisado">Revisados</option></select><ChevronDown size={14}/></label><button className="quiet-button" onClick={openTrash}><Trash2 size={15}/> Papelera</button></div></div>
    <div className="data-table-wrap"><table className="data-table"><thead><tr><th>PERSONA / PARTIDA</th><th>TIPO</th><th>FECHA</th><th>PARROQUIA Y LUGAR</th><th>REFERENCIA</th><th>ESTADO</th><th>ACCIONES</th></tr></thead><tbody>
      {shown.map(r => <tr key={r.id} onDoubleClick={() => openEdit(r)}><td><button className="table-person" onClick={() => openEdit(r)}><span className="table-avatar">{(r.main_name?.[0] || 'S').toUpperCase()}{(r.main_surnames?.[0] || '').toUpperCase()}</span><span><strong>{fullName(r)}</strong><small>{r.type === 'matrimonio' && (r.second_name || r.second_surnames) ? `y ${[r.second_name, r.second_surnames].filter(Boolean).join(' ')}` : r.father_name ? `Padres: ${r.father_name}${r.mother_name ? ` y ${r.mother_name}` : ''}` : r.record_mode === 'literal' ? 'Transcripción literal' : 'Abrir ficha documental'}</small></span></button></td><td><span className={`type-pill ${r.type}`}>{TYPE_LABELS[r.type] || 'Otro'}</span></td><td>{dateLabel(r.event_date)}</td><td>{r.parish || <span className="dim">Sin indicar</span>}<small className="table-subline">{[r.city,r.municipality,r.province,r.country].filter(Boolean).join(' · ')}</small></td><td>{reference(r)}</td><td><span className={`status-pill ${r.status === 'revisado' ? 'done' : 'waiting'}`}><i/>{r.status === 'revisado' ? 'Revisado' : 'Pendiente'}</span></td><td><div className="row-actions"><button title="Editar partida" onClick={() => openEdit(r)}><Pencil size={15}/></button><button title="Preparar certificación e imprimir/exportar PDF" onClick={() => onCertify(r)}><FileCheck2 size={15}/></button><button title="Enviar a papelera" onClick={() => removeRecord(r)}><Trash2 size={15}/></button></div></td></tr>)}
      {shown.length === 0 && <tr><td colSpan={7}><EmptyState icon={<Search size={23}/>} title={loading ? 'Cargando archivo…' : 'No hay partidas en esta subsección'} text="Crea la primera partida de este tipo o cambia a otro tipo de libro." action={!loading ? <button className="primary-button" onClick={openNew}><Plus size={16}/> Nueva partida</button> : undefined}/></td></tr>}
    </tbody></table></div><div className="table-footer"><span>Los registros se guardan localmente en este equipo.</span><span>Doble clic para editar · icono de documento para certificar.</span></div>
  </section>;
}

function RegistrationLanding({selectedType,setSelectedType,onChoose}:{selectedType:string;setSelectedType:(v:string)=>void;onChoose:(mode:'extracto'|'literal')=>void}) {
  const types = [
    {value:'bautismo',label:'Bautismo',detail:'Datos del bautizado, padres, abuelos y celebrante',icon:BookOpen},
    {value:'matrimonio',label:'Matrimonio',detail:'Contrayentes, filiación y datos del acto',icon:HeartHandshake},
    {value:'defuncion',label:'Defunción',detail:'Difunto, parentesco, fecha y referencia de entierro',icon:BookMarked}
  ];
  return <div className="registration-landing">
    <section className="registration-intro"><span className="registration-seal"><FilePlus2 size={25}/></span><div><div className="eyebrow">NUEVO REGISTRO DOCUMENTAL</div><h2>¿Cómo vas a registrar esta partida?</h2><p>Elige el tipo de libro y después el formulario. Puedes guardar un extracto con campos organizados o conservar la transcripción literal completa. Cuba viene preconfigurada con sus provincias y {CUBA_MUNICIPALITY_COUNT} municipios para trabajar sin conexión.</p></div></section>
    <section className="panel registration-type-panel"><div className="panel-heading"><div><h3>1. Tipo de registro</h3><p>Selecciona la subsección documental a la que pertenece.</p></div></div><div className="registration-type-grid">{types.map(item=>{const Icon=item.icon;return <button key={item.value} className={`registration-type-card ${selectedType===item.value?'selected':''}`} onClick={()=>setSelectedType(item.value)}><span><Icon size={21}/></span><strong>{item.label}</strong><small>{item.detail}</small>{selectedType===item.value&&<i><Check size={14}/></i>}</button>;})}</div></section>
    <section className="panel registration-mode-panel"><div className="panel-heading"><div><h3>2. Elige el formulario</h3><p>Ambas modalidades guardan la referencia del libro y permiten adjuntar imágenes.</p></div></div><div className="registration-mode-grid"><button onClick={()=>onChoose('extracto')} className="registration-mode-card"><span className="mode-card-icon"><ClipboardList size={23}/></span><span className="mode-card-text"><strong>Formulario de extracto</strong><small>Campos separados para nombres, fechas, padres, abuelos, parroquia y referencia. Ideal para indexar y buscar rápidamente.</small><b>Comenzar extracto <ChevronRight size={15}/></b></span></button><button onClick={()=>onChoose('literal')} className="registration-mode-card"><span className="mode-card-icon literal"><FileText size={23}/></span><span className="mode-card-text"><strong>Transcripción literal</strong><small>Recuadro amplio para transcribir manualmente la partida respetando su escritura original.</small><b>Comenzar transcripción <ChevronRight size={15}/></b></span></button></div></section>
  </div>;
}

function AdvancedSearchPage({quickSearch,onEdit,onCertify,notify}:{quickSearch:string;onEdit:(r:ArchiveRecord)=>void;onCertify:(r:ArchiveRecord)=>void;notify:(n:{kind:'success'|'error'|'info';text:string})=>void}) {
  type Filters = {any:string;name:string;surname:string;parish:string;city:string;country:string;province:string;municipality:string;type:string;exactDate:string;nearYear:string;fromYear:string;toYear:string};
  const blank:Filters = {any:quickSearch,name:'',surname:'',parish:'',city:'',country:'',province:'',municipality:'',type:'todos',exactDate:'',nearYear:'',fromYear:'',toYear:''};
  const [filters,setFilters] = useState<Filters>(blank);
  const [results,setResults] = useState<ArchiveRecord[]>([]);
  const [busy,setBusy] = useState(false);
  useEffect(()=>setFilters(prev=>({...prev,any:quickSearch})),[quickSearch]);
  useEffect(()=>{
    let cancelled=false;
    const timer=window.setTimeout(()=>{
      setBusy(true);
      window.archiveApi.searchRecords(filters).then(r=>{if(!cancelled)setResults(r);}).catch(e=>{if(!cancelled)notify({kind:'error',text:`No se pudo completar la búsqueda: ${String(e)}`});}).finally(()=>{if(!cancelled)setBusy(false);});
    },220);
    return ()=>{cancelled=true;window.clearTimeout(timer);};
  },[filters,notify]);
  const set = (key:keyof Filters,value:string) => setFilters(prev=>{
    if(key==='exactDate' && value) return {...prev,exactDate:value,nearYear:'',fromYear:'',toYear:'' ,[key]:value};
    if(key==='nearYear' && value) return {...prev,nearYear:value,exactDate:'',fromYear:'',toYear:''};
    if((key==='fromYear'||key==='toYear')&&value) return {...prev,[key]:value,exactDate:'',nearYear:''};
    return {...prev,[key]:value};
  });
  const reset = () => setFilters({...blank,any:''});
  return <div className="advanced-search-page"><section className="panel advanced-search-panel"><div className="panel-heading"><div><h3>Filtros de búsqueda</h3><p>Se pueden combinar varios criterios. Los filtros geográficos funcionan sin conexión.</p></div><span className="place-form-icon"><Search size={19}/></span></div>
    <div className="search-filter-grid"><Field label="Búsqueda general"><input value={filters.any} onChange={e=>set('any',e.target.value)} placeholder="Nombre, referencia o transcripción"/></Field><Field label="Nombre"><input value={filters.name} onChange={e=>set('name',e.target.value)} placeholder="Nombre propio"/></Field><Field label="Apellido"><input value={filters.surname} onChange={e=>set('surname',e.target.value)} placeholder="Uno o ambos apellidos"/></Field><Field label="Tipo de registro"><select value={filters.type} onChange={e=>set('type',e.target.value)}><option value="todos">Todos los tipos</option>{Object.entries(TYPE_LABELS).map(([value,label])=><option value={value} key={value}>{label}</option>)}</select></Field>
      <Field label="Parroquia"><input value={filters.parish} onChange={e=>set('parish',e.target.value)} placeholder="Nombre de parroquia"/></Field><Field label="Localidad / ciudad"><input value={filters.city} onChange={e=>set('city',e.target.value)} placeholder="Lugar"/></Field><Field label="País"><input value={filters.country} onChange={e=>set('country',e.target.value)} placeholder="Cuba, España…"/></Field><Field label="Provincia"><input value={filters.province} onChange={e=>set('province',e.target.value)} placeholder="Provincia o región"/></Field><Field label="Municipio"><input value={filters.municipality} onChange={e=>set('municipality',e.target.value)} placeholder="Municipio"/></Field><Field label="Fecha exacta"><input value={filters.exactDate} onChange={e=>set('exactDate',e.target.value)} placeholder="AAAA-MM-DD o año"/></Field><Field label="Año aproximado (±5 años)"><input value={filters.nearYear} onChange={e=>set('nearYear',e.target.value)} inputMode="numeric" placeholder="Ej. hacia 1880"/></Field><Field label="Año desde"><input value={filters.fromYear} onChange={e=>set('fromYear',e.target.value)} inputMode="numeric" placeholder="Ej. 1880"/></Field><Field label="Año hasta"><input value={filters.toYear} onChange={e=>set('toYear',e.target.value)} inputMode="numeric" placeholder="Ej. 1900"/></Field></div>
    <div className="search-panel-footer"><span><Search size={15}/> La búsqueda se actualiza automáticamente mientras cambias los filtros.</span><button className="quiet-button" onClick={reset}>Limpiar filtros</button></div></section>
    <section className="panel search-results-panel"><div className="table-toolbar"><div className="results-count"><strong>{results.length.toLocaleString('es-ES')}</strong> resultados {busy?'· Buscando…':''}</div><span className="search-result-note">Hasta 10.000 coincidencias por consulta</span></div><div className="data-table-wrap"><table className="data-table"><thead><tr><th>PERSONA / PARTIDA</th><th>TIPO</th><th>FECHA</th><th>PARROQUIA Y LUGAR</th><th>REFERENCIA</th><th>ACCIONES</th></tr></thead><tbody>{results.map(r=><tr key={r.id}><td><button className="table-person" onClick={()=>onEdit(r)}><span className="table-avatar">{(r.main_name?.[0]||'S').toUpperCase()}{(r.main_surnames?.[0]||'').toUpperCase()}</span><span><strong>{fullName(r)}</strong><small>{r.type==='matrimonio'&&r.second_name?`y ${r.second_name} ${r.second_surnames}`:r.record_mode==='literal'?'Transcripción literal':''}</small></span></button></td><td><span className={`type-pill ${r.type}`}>{TYPE_LABELS[r.type]||r.type}</span></td><td>{dateLabel(r.event_date)}</td><td>{r.parish||'Sin parroquia'}<small className="table-subline">{[r.city,r.municipality,r.province,r.country].filter(Boolean).join(' · ')}</small></td><td>{reference(r)}</td><td><div className="row-actions"><button title="Abrir y editar partida" onClick={()=>onEdit(r)}><Pencil size={15}/></button><button title="Certificar y exportar PDF/JPG" onClick={()=>onCertify(r)}><FileCheck2 size={15}/></button></div></td></tr>)}{results.length===0&&!busy&&<tr><td colSpan={6}><EmptyState icon={<Search size={23}/>} title="No encontramos coincidencias" text="Prueba una fecha más amplia, parte del apellido o limpia alguno de los filtros."/></td></tr>}</tbody></table></div></section>
  </div>;
}

function StatisticsPage({stats}:{stats:ArchiveStats}) {
  const count=(type:string)=>stats.byType.find(x=>x.type===type)?.n||0;
  return <div className="statistics-page"><div className="stats-grid stats-grid-v2"><StatCard label="TOTAL DE PARTIDAS" value={stats.total.toLocaleString('es-ES')} detail="Todos los registros guardados" icon={<Files size={18}/>} tone="navy"/><StatCard label="BAUTISMOS" value={count('bautismo').toLocaleString('es-ES')} detail="Partidas de bautismo" icon={<BookOpen size={18}/>} tone="gold"/><StatCard label="MATRIMONIOS" value={count('matrimonio').toLocaleString('es-ES')} detail="Partidas matrimoniales" icon={<HeartHandshake size={18}/>} tone="violet"/><StatCard label="DEFUNCIONES" value={count('defuncion').toLocaleString('es-ES')} detail="Partidas de defunción" icon={<BookMarked size={18}/>} tone="green"/><StatCard label="CON IMÁGENES" value={stats.withImages.toLocaleString('es-ES')} detail="Con fuente adjunta" icon={<ImageIcon size={18}/>} tone="green"/><StatCard label="CON TRANSCRIPCIÓN" value={stats.withTranscription.toLocaleString('es-ES')} detail="Transcripción guardada" icon={<FileText size={18}/>} tone="gold"/><StatCard label="PENDIENTES" value={stats.pending.toLocaleString('es-ES')} detail="Marcados para revisar" icon={<ClipboardList size={18}/>} tone="violet"/></div>
    <div className="statistics-grid"><SimpleBarGroup title="Partidas por tipo" subtitle="Distribución de los registros" items={stats.byType.map(x=>({name:TYPE_LABELS[x.type]||x.type,n:x.n}))}/><SimpleBarGroup title="Partidas por provincia" subtitle="Provincias o regiones con más registros" items={stats.byProvince}/><SimpleBarGroup title="Partidas por municipio" subtitle="Municipios con más registros" items={stats.byMunicipality}/><SimpleBarGroup title="Partidas por país" subtitle="Procedencia geográfica documentada" items={stats.byCountry}/><SimpleBarGroup title="Partidas por parroquia" subtitle="Parroquias con mayor volumen documental" items={stats.byParish}/><section className="panel stats-year-panel"><div className="panel-heading"><div><h3>Actividad por año del acto</h3><p>Distribución según la fecha registrada en cada partida.</p></div><CalendarDays size={19} className="panel-heading-icon"/></div>{stats.byYear.length?<div className="stats-year-list">{stats.byYear.map(item=><div key={item.year} className="stats-year-row"><span>{item.year}</span><div className="stats-bar-track"><i style={{width:`${Math.max(2,item.n/Math.max(1,...stats.byYear.map(x=>x.n))*100)}%`}}/></div><b>{item.n.toLocaleString('es-ES')}</b></div>)}</div>:<EmptyMini text="Las estadísticas por año aparecerán cuando guardes partidas con fecha."/>}</section></div>
    <div className="statistics-footnote"><ShieldCheck size={17}/><span>Las cifras se calculan directamente a partir de la base de datos local, incluyendo registros no visibles en la subsección actual del Archivo.</span></div>
  </div>;
}
function SimpleBarGroup({title,subtitle,items}:{title:string;subtitle:string;items:{name:string;n:number}[]}) {
  const max=Math.max(1,...items.map(x=>x.n));
  return <section className="panel simple-bar-panel"><div className="panel-heading"><div><h3>{title}</h3><p>{subtitle}</p></div></div>{items.length?<div className="simple-bar-list">{items.map((item,i)=><div className="simple-bar-row" key={`${item.name}-${i}`}><div className="simple-bar-caption"><span title={item.name}>{item.name}</span><b>{item.n.toLocaleString('es-ES')}</b></div><div className="simple-bar-track"><i style={{width:`${Math.max(2,item.n/max*100)}%`}}/></div></div>)}</div>:<EmptyMini text="Todavía no hay datos suficientes."/>}</section>;
}

function RecordEditor({record,catalog,onClose,onSave,notify,standalone=false,initialMode='extracto'}:{record:ArchiveRecord;catalog:ArchiveCatalog[];onClose:()=>void;onSave:(r:ArchiveRecord,next:boolean)=>void;notify:(n:{kind:'success'|'error'|'info';text:string})=>void;standalone?:boolean;initialMode?:'extracto'|'literal'}) {
  const [form,setForm] = useState<ArchiveRecord>({...DEFAULT_RECORD,...record,record_mode:record.record_mode||initialMode});
  const [saving,setSaving] = useState(false);
  const [more,setMore] = useState(false);
  const [attachments,setAttachments] = useState<ArchiveAttachment[]>([]);
  const [previewAttachment,setPreviewAttachment] = useState<ArchiveAttachment | null>(null);
  const [placeMode,setPlaceMode] = useState<'cuba'|'extranjero'>(form.country && form.country.toLocaleLowerCase()!=='cuba' ? 'extranjero' : 'cuba');
  const [customProvince,setCustomProvince] = useState(Boolean(form.province && !CUBA_PROVINCES.includes(form.province)));
  useEffect(() => { if (form.id) window.archiveApi.listAttachments(form.id).then(setAttachments).catch(()=>setAttachments([])); }, [form.id]);
  type EditableField = Exclude<keyof ArchiveRecord, 'id'|'created_at'|'updated_at'|'deleted_at'>;
  const set = (key:EditableField,value:string) => setForm(prev => ({...prev,[key]:value}));
  const doSave = async (next = false) => {
    const hasName = Boolean(form.main_name.trim() || form.main_surnames.trim() || form.second_name.trim() || form.second_surnames.trim());
    const hasLiteralContent = Boolean(form.transcription.trim() || form.volume.trim() || form.folio.trim() || form.record_number.trim());
    if (form.record_mode === 'literal' ? (!hasName && !hasLiteralContent) : (!form.main_name.trim() && !form.main_surnames.trim())) {
      notify({kind:'error',text:form.record_mode==='literal'?'Añade un nombre, una referencia de libro o la transcripción literal antes de guardar.':'Escribe al menos el nombre o los apellidos de la persona.'}); return;
    }
    setSaving(true);
    try {
      const saved = await window.archiveApi.saveRecord(form);
      setForm({...DEFAULT_RECORD,...saved});
      if (next) {
        onSave(saved,true);
        setForm({...DEFAULT_RECORD,type:saved.type,record_mode:saved.record_mode,parish:saved.parish,city:saved.city,municipality:saved.municipality,province:saved.province,country:saved.country,volume:saved.volume,status:'pendiente'});
        setAttachments([]);
      } else onSave(saved,false);
    } catch(e) { notify({kind:'error',text:`No se pudo guardar la partida: ${String(e)}`}); }
    finally { setSaving(false); }
  };
  const addImages = async () => { if (!form.id) { notify({kind:'info',text:'Guarda primero la partida y luego adjunta las imágenes.'}); return; } try { const added = await window.archiveApi.addAttachments(form.id); setAttachments(prev => [...added,...prev]); if (added.length) notify({kind:'success',text:`Se adjuntaron ${added.length} archivo(s).`}); } catch(e) { notify({kind:'error',text:String(e)}); } };
  const isMarriage = form.type === 'matrimonio';
  const isDeath = form.type === 'defuncion';
  const isBaptism = form.type === 'bautismo';
  const chooseCountryMode = (mode:'cuba'|'extranjero') => {
    setPlaceMode(mode);
    if(mode==='cuba') {
      set('country','Cuba');
      if (form.municipality === CUBA_SPECIAL_MUNICIPALITY && !form.province) { setCustomProvince(false); return; }
      if(!CUBA_PROVINCES.includes(form.province)) { set('province',''); setCustomProvince(false); }
      if(!CUBA_ADMIN[form.province]?.includes(form.municipality)) set('municipality','');
    } else { const wasCuba=form.country.toLocaleLowerCase()==='cuba'; set('country',wasCuba?'':form.country); if(wasCuba){set('province','');set('municipality','');set('city','');} setCustomProvince(true); }
  };
  const chooseProvince = (value:string) => {
    if(value==='') { setCustomProvince(false); set('province',''); set('municipality',''); return; }
    if(value==='__historica__') { setCustomProvince(true); set('province',''); set('municipality',''); return; }
    if(value==='__isla__') { setCustomProvince(false); set('province',''); set('municipality',CUBA_SPECIAL_MUNICIPALITY); return; }
    setCustomProvince(false); set('province',value);
    if(value!==form.province && !CUBA_ADMIN[value]?.includes(form.municipality)) set('municipality','');
  };
  const provinceChoice = customProvince ? '__historica__' : (!form.province && form.municipality===CUBA_SPECIAL_MUNICIPALITY ? '__isla__' : form.province);
  const locationFields = <>
    <div className="location-mode"><span className="location-mode-label">Lugar del registro</span><div className="segmented-control"><button type="button" className={placeMode==='cuba'?'selected':''} onClick={()=>chooseCountryMode('cuba')}><MapPin size={15}/> Cuba</button><button type="button" className={placeMode==='extranjero'?'selected':''} onClick={()=>chooseCountryMode('extranjero')}><ExternalLink size={15}/> Extranjero</button></div></div>
    {placeMode==='cuba' ? <>
      <Field label="País"><input value="Cuba" readOnly aria-readonly="true"/></Field>
      <Field label="Provincia cubana o municipio especial"><select value={provinceChoice} onChange={e=>chooseProvince(e.target.value)}><option value="">Selecciona provincia…</option>{CUBA_PROVINCES.map(pr=><option key={pr} value={pr}>{pr}</option>)}<option value="__isla__">Municipio especial: Isla de la Juventud</option><option value="__historica__">Otra / región histórica…</option></select></Field>
      <Field label="Municipio cubano">{customProvince ? <input value={form.municipality} onChange={e=>set('municipality',e.target.value)} placeholder="Escribe el municipio o término histórico"/> : !form.province && form.municipality===CUBA_SPECIAL_MUNICIPALITY ? <input value={CUBA_SPECIAL_MUNICIPALITY} readOnly aria-readonly="true"/> : <select value={form.municipality} onChange={e=>set('municipality',e.target.value)} disabled={!form.province}><option value="">{form.province?'Selecciona municipio…':'Selecciona primero la provincia'}</option>{(CUBA_ADMIN[form.province]||[]).map(m=><option key={m} value={m}>{m}</option>)}</select>}</Field>
    </> : <>
      <Field label="País extranjero"><input value={form.country==='Cuba'?'':form.country} onChange={e=>set('country',e.target.value)} placeholder="Escribe el país"/></Field>
      <Field label="Provincia / región extranjera"><input value={form.province} onChange={e=>set('province',e.target.value)} placeholder="Provincia, estado o región"/></Field>
      <Field label="Municipio / distrito extranjero"><input value={form.municipality} onChange={e=>set('municipality',e.target.value)} placeholder="Municipio, distrito o equivalente"/></Field>
    </>}
    <Field label="Ciudad o localidad"><input list="city-options" value={form.city} onChange={e=>set('city',e.target.value)} placeholder="Ciudad, pueblo, barrio o localidad"/><datalist id="city-options">{catalog.filter(c=>c.kind==='city').map(c=><option key={c.id} value={c.name}/>)}</datalist></Field>
    <Field label="Parroquia / iglesia"><input list="parish-options" value={form.parish} onChange={e=>set('parish',e.target.value)} placeholder="Escribe o elige una parroquia"/><datalist id="parish-options">{catalog.filter(c=>c.kind==='parish').map(c=><option key={c.id} value={c.name}/>)}</datalist></Field>
  </>;
  return <div className={standalone?'record-editor-standalone':'modal-scrim'} onMouseDown={e=>{if(!standalone && e.target===e.currentTarget) onClose();}}><section className={`editor-modal ${standalone?'editor-inline':''}`}>
    <header className="editor-header"><div className="editor-title-icon"><FilePlus2 size={21}/></div><div><div className="eyebrow">{form.id ? `PARTIDA N.º ${form.id}` : 'NUEVO REGISTRO'} · {form.record_mode==='literal'?'TRANSCRIPCIÓN LITERAL':'FORMULARIO DE EXTRACTO'}</div><h2>{form.id ? 'Editar partida' : 'Indexar una partida'}</h2><p>Solo tienes que introducir los datos que consten en el documento original.</p></div><button className="icon-button close-editor" onClick={onClose} aria-label="Cerrar formulario"><X size={19}/></button></header>
    <div className="editor-scroll">
      <div className="form-section"><div className="mode-switch-heading"><div><div className="eyebrow">MODALIDAD DE CAPTURA</div><h3>¿Cómo está indexando esta partida?</h3><p>Puedes cambiar de modalidad sin perder los datos introducidos.</p></div><div className="mode-switch"><button type="button" onClick={()=>set('record_mode','extracto')} className={form.record_mode!=='literal'?'active':''}><ClipboardList size={16}/> Extracto</button><button type="button" onClick={()=>set('record_mode','literal')} className={form.record_mode==='literal'?'active':''}><FileText size={16}/> Literal</button></div></div>
        <div className="form-grid two"><Field label="Tipo de registro" required><select value={form.type} onChange={e=>set('type',e.target.value)}>{!TYPE_OPTIONS.some(o=>o.value===form.type) && <option value={form.type}>{TYPE_LABELS[form.type] || form.type}</option>}{TYPE_OPTIONS.map(o=><option key={o.value} value={o.value}>{o.label}</option>)}</select></Field><Field label={isBaptism?'Fecha de bautismo':isMarriage?'Fecha del matrimonio':'Fecha de defunción'}><input type="text" value={form.event_date} onChange={e=>set('event_date',e.target.value)} placeholder="AAAA-MM-DD, año o fecha aproximada"/></Field>
        <Field label={form.record_mode==='literal'?'Nombre identificado (opcional)':isBaptism?'Nombre(s) del bautizado':isMarriage?'Primer contrayente · nombre(s)':'Nombre(s) del difunto'} required={form.record_mode!=='literal'}><input autoFocus value={form.main_name} onChange={e=>set('main_name',e.target.value)} placeholder={form.record_mode==='literal'?'Si puede identificarse en la partida':isBaptism?'Nombre(s) del bautizado':isMarriage?'Nombre(s) del primer contrayente':'Nombre(s) del difunto'}/></Field><Field label={isMarriage?'Primer contrayente · apellidos':'Apellidos'}><input value={form.main_surnames} onChange={e=>set('main_surnames',e.target.value)} placeholder="Apellidos tal como aparecen en la partida"/></Field>
        {isMarriage && <><Field label="Segundo contrayente · nombre(s) (opcional)"><input value={form.second_name} onChange={e=>set('second_name',e.target.value)} placeholder="Nombre(s)"/></Field><Field label="Segundo contrayente · apellidos"><input value={form.second_surnames} onChange={e=>set('second_surnames',e.target.value)} placeholder="Apellidos"/></Field></>}
      </div>
    </div>

    {form.record_mode==='extracto' && <>
      {isBaptism && <div className="form-section"><div className="form-section-title"><span>01</span><div><h3>Datos del bautizado y sus padres</h3><p>Completa los datos que consten; lo desconocido puede quedar en blanco.</p></div></div><div className="form-grid two">
        <Field label="Fecha de nacimiento"><input value={form.birth_date} onChange={e=>set('birth_date',e.target.value)} placeholder="Fecha, año o aproximación"/></Field>
        <Field label="Presbítero que realizó el bautismo"><input value={form.priest} onChange={e=>set('priest',e.target.value)} placeholder="Nombre del sacerdote"/></Field>
        <Field label="Nombre del padre"><input value={form.father_name} onChange={e=>set('father_name',e.target.value)} placeholder="Nombre y apellidos"/></Field><Field label="Naturaleza del padre"><input value={form.father_nature} onChange={e=>set('father_nature',e.target.value)} placeholder="Lugar de nacimiento / naturaleza"/></Field>
        <Field label="Nombre de la madre"><input value={form.mother_name} onChange={e=>set('mother_name',e.target.value)} placeholder="Nombre y apellidos"/></Field><Field label="Naturaleza de la madre"><input value={form.mother_nature} onChange={e=>set('mother_nature',e.target.value)} placeholder="Lugar de nacimiento / naturaleza"/></Field>
      </div><div className="grandparents-block"><div className="grandparents-title"><Users size={17}/> Abuelos paternos</div><div className="form-grid three"><Field label="Abuelo paterno"><input value={form.paternal_grandfather_name} onChange={e=>set('paternal_grandfather_name',e.target.value)} placeholder="Nombre y apellidos"/></Field><Field label="Abuela paterna"><input value={form.paternal_grandmother_name} onChange={e=>set('paternal_grandmother_name',e.target.value)} placeholder="Nombre y apellidos"/></Field><Field label="Naturaleza de ambos / notas"><input value={form.paternal_grandparents_nature} onChange={e=>set('paternal_grandparents_nature',e.target.value)} placeholder="Naturalezas, si constan"/></Field></div><div className="grandparents-title maternal"><Users size={17}/> Abuelos maternos</div><div className="form-grid three"><Field label="Abuelo materno"><input value={form.maternal_grandfather_name} onChange={e=>set('maternal_grandfather_name',e.target.value)} placeholder="Nombre y apellidos"/></Field><Field label="Abuela materna"><input value={form.maternal_grandmother_name} onChange={e=>set('maternal_grandmother_name',e.target.value)} placeholder="Nombre y apellidos"/></Field><Field label="Naturaleza de ambos / notas"><input value={form.maternal_grandparents_nature} onChange={e=>set('maternal_grandparents_nature',e.target.value)} placeholder="Naturalezas, si constan"/></Field></div></div></div>}
      {isMarriage && <div className="form-section"><div className="form-section-title"><span>01</span><div><h3>Contrayentes y filiación</h3><p>Una sola partida con los dos contrayentes.</p></div></div><div className="form-grid two"><Field label="Segundo contrayente · nombre(s)"><input value={form.second_name} onChange={e=>set('second_name',e.target.value)} placeholder="Nombre(s)"/></Field><Field label="Segundo contrayente · apellidos"><input value={form.second_surnames} onChange={e=>set('second_surnames',e.target.value)} placeholder="Apellidos"/></Field><Field label="Padre del primer contrayente"><input value={form.father_name} onChange={e=>set('father_name',e.target.value)} placeholder="Nombre del padre"/></Field><Field label="Naturaleza del padre"><input value={form.father_nature} onChange={e=>set('father_nature',e.target.value)} placeholder="Naturaleza"/></Field><Field label="Madre del primer contrayente"><input value={form.mother_name} onChange={e=>set('mother_name',e.target.value)} placeholder="Nombre de la madre"/></Field><Field label="Naturaleza de la madre"><input value={form.mother_nature} onChange={e=>set('mother_nature',e.target.value)} placeholder="Naturaleza"/></Field><Field label="Padre del segundo contrayente"><input value={form.second_father_name} onChange={e=>set('second_father_name',e.target.value)} placeholder="Nombre del padre"/></Field><Field label="Naturaleza del padre del segundo contrayente"><input value={form.second_father_nature} onChange={e=>set('second_father_nature',e.target.value)} placeholder="Naturaleza"/></Field><Field label="Madre del segundo contrayente"><input value={form.second_mother_name} onChange={e=>set('second_mother_name',e.target.value)} placeholder="Nombre de la madre"/></Field><Field label="Naturaleza de la madre del segundo contrayente"><input value={form.second_mother_nature} onChange={e=>set('second_mother_nature',e.target.value)} placeholder="Naturaleza"/></Field><Field label="Presbítero / celebrante"><input value={form.priest} onChange={e=>set('priest',e.target.value)} placeholder="Nombre del sacerdote"/></Field></div></div>}
      {isDeath && <div className="form-section"><div className="form-section-title"><span>01</span><div><h3>Datos de la persona fallecida</h3><p>Registra únicamente la información que se conserve en la partida.</p></div></div><div className="form-grid two"><Field label="Fecha de nacimiento"><input value={form.birth_date} onChange={e=>set('birth_date',e.target.value)} placeholder="Fecha, año o aproximación"/></Field><Field label="Fecha de entierro"><input value={form.burial_date} onChange={e=>set('burial_date',e.target.value)} placeholder="Si es distinta de la defunción"/></Field><Field label="Edad indicada"><input value={form.age} onChange={e=>set('age',e.target.value)} placeholder="Ej. 68 años"/></Field><Field label="Cónyuge"><input value={form.spouse_name} onChange={e=>set('spouse_name',e.target.value)} placeholder="Nombre, si consta"/></Field><Field label="Nombre del padre"><input value={form.father_name} onChange={e=>set('father_name',e.target.value)} placeholder="Nombre, si consta"/></Field><Field label="Naturaleza del padre"><input value={form.father_nature} onChange={e=>set('father_nature',e.target.value)} placeholder="Naturaleza, si consta"/></Field><Field label="Nombre de la madre"><input value={form.mother_name} onChange={e=>set('mother_name',e.target.value)} placeholder="Nombre, si consta"/></Field><Field label="Naturaleza de la madre"><input value={form.mother_nature} onChange={e=>set('mother_nature',e.target.value)} placeholder="Naturaleza, si consta"/></Field><Field label="Presbítero / celebrante"><input value={form.priest} onChange={e=>set('priest',e.target.value)} placeholder="Nombre, si consta"/></Field></div></div>}
    </>}

    <div className="form-section"><div className="form-section-title"><span>{form.record_mode==='literal'?'01':'02'}</span><div><h3>Procedencia y referencia del libro</h3><p>El lugar y la referencia permiten volver a la partida original.</p></div></div><div className="form-grid two">{locationFields}<div className="form-grid three nested-fields"><Field label="Libro / tomo"><input value={form.volume} onChange={e=>set('volume',e.target.value)} placeholder="Ej. Libro 14"/></Field><Field label="Folio / página"><input value={form.folio} onChange={e=>set('folio',e.target.value)} placeholder="Ej. 32v"/></Field><Field label="Número de la partida"><input value={form.record_number} onChange={e=>set('record_number',e.target.value)} placeholder="Ej. 108"/></Field></div></div></div>

    <div className={`form-section ${form.record_mode==='literal'?'literal-transcription-section':''}`}><div className="form-section-title"><span>{form.record_mode==='literal'?'02':'03'}</span><div><h3>{form.record_mode==='literal'?'Transcripción literal completa':'Transcripción original (opcional)'}</h3><p>{form.record_mode==='literal'?'Transcribe manualmente la partida tal como aparece, incluidas abreviaturas y grafías antiguas.':'Conserva aquí el texto completo cuando sea útil, además de los campos indexados.'}</p></div></div><Field label={form.record_mode==='literal'?'Texto original de la partida':'Transcripción / observaciones de la fuente'}><textarea className="transcription-area" value={form.transcription} onChange={e=>set('transcription',e.target.value)} placeholder={form.record_mode==='literal'?'Escribe aquí la transcripción completa del documento…':'Transcribe el texto original o anota lecturas dudosas…'} rows={form.record_mode==='literal'?12:6}/></Field><Field label="Notas de investigación (opcional)"><textarea value={form.notes} onChange={e=>set('notes',e.target.value)} placeholder="Lecturas dudosas, variantes, contexto o tareas pendientes…" rows={2}/></Field></div>

    <div className="form-section attachments-section"><div className="attachments-heading"><div className="form-section-title"><span>{form.record_mode==='literal'?'03':'04'}</span><div><h3>Fotografías y documentos</h3><p>Adjunta imágenes originales o archivos de referencia a esta partida.</p></div></div><button className="quiet-button" onClick={addImages}><Plus size={15}/> Adjuntar archivos</button></div>
      {attachments.length ? <div className="attachment-list">{attachments.map(a=><button key={a.id} onClick={()=>a.dataUrl ? setPreviewAttachment(a) : void window.archiveApi.openAttachment(a.path)} className="attachment-item" title={a.dataUrl ? 'Previsualizar imagen' : 'Abrir archivo'}>{a.dataUrl ? <img className="attachment-thumb" src={a.dataUrl} alt="Miniatura del documento"/> : <span className="attachment-icon">{a.mime_type === 'application/pdf' ? <FileText size={18}/> : <ImageIcon size={18}/>}</span>}<span><strong>{a.original_name}</strong><small>{a.mime_type || 'Documento adjunto'}</small></span><ExternalLink size={14}/></button>)}</div> : <div className="attachment-empty"><ImageIcon size={19}/><span>{form.id ? 'Todavía no hay archivos adjuntos.' : 'Guarda la partida para poder adjuntar fotografías y documentos.'}</span></div>}
    </div>
    <div className="form-section compact-section"><button className="more-toggle" onClick={()=>setMore(!more)}>{more ? <ChevronDown size={16}/> : <ChevronRight size={16}/>} Control de revisión</button>{more && <div className="form-grid two more-grid"><Field label="Estado de la partida"><select value={form.status} onChange={e=>set('status',e.target.value)}><option value="pendiente">Pendiente de revisión</option><option value="revisado">Revisado</option></select></Field><div className="field-help-box"><AlertCircle size={15}/><span>El estado no afecta al guardado; indica si ya se ha revisado la transcripción.</span></div></div>}</div>
    </div>
    <footer className="editor-footer"><span className="required-note"><i/> {form.record_mode==='literal'?'Nombre, referencia o transcripción para identificar la partida.':'Nombre y apellidos son los datos mínimos del extracto.'}</span><div><button className="quiet-button" onClick={onClose}>Volver</button><button className="secondary-button" disabled={saving} onClick={()=>void doSave(true)}><Save size={15}/> Guardar y siguiente</button><button className="primary-button" disabled={saving} onClick={()=>void doSave(false)}><Check size={16}/>{saving ? 'Guardando…' : 'Guardar partida'}</button></div></footer>
  </section>{previewAttachment && <div className="image-preview-scrim" onMouseDown={e=>{if(e.target===e.currentTarget)setPreviewAttachment(null);}}><div className="image-preview-modal"><div className="image-preview-toolbar"><span>{previewAttachment.original_name}</span><button className="icon-button" onClick={()=>setPreviewAttachment(null)}><X size={18}/></button></div><img src={previewAttachment.dataUrl} alt={previewAttachment.original_name}/></div></div>}</div>;
}

function Field({label,children,required=false}:{label:string;children:React.ReactNode;required?:boolean}) { return <label className="field"><span>{label}{required && <b className="req"> *</b>}</span>{children}</label>; }

function PeoplePage({records,onOpen}:{records:ArchiveRecord[];onOpen:(r:ArchiveRecord)=>void}) {
  const [personSearch,setPersonSearch] = useState('');
  const people = useMemo(() => {
    const items: {key:string;name:string;role:string;record:ArchiveRecord;date:string}[] = [];
    for (const r of records) {
      if (r.main_name || r.main_surnames) items.push({key:`${r.id}-main`,name:fullName(r),role:r.type === 'matrimonio' ? 'Primer contrayente' : 'Persona principal',record:r,date:r.event_date});
      if (r.type === 'matrimonio' && (r.second_name || r.second_surnames)) items.push({key:`${r.id}-second`,name:[r.second_name,r.second_surnames].filter(Boolean).join(' '),role:'Segundo contrayente',record:r,date:r.event_date});
    }
    const q = personSearch.trim().toLocaleLowerCase();
    return items.filter(p => !q || `${p.name} ${p.role} ${p.record.parish}`.toLocaleLowerCase().includes(q)).sort((a,b)=>a.name.localeCompare(b.name,'es'));
  },[records,personSearch]);
  return <section className="panel people-panel"><div className="subpage-toolbar"><div><h3>Personas mencionadas en el archivo</h3><p>Esta vista reúne los nombres indexados. La coincidencia de nombres no implica identidad confirmada.</p></div><div className="people-search"><Search size={16}/><input placeholder="Filtrar personas…" value={personSearch} onChange={e=>setPersonSearch(e.target.value)}/></div></div>
    <div className="people-note"><Users size={17}/><span>Primero se muestran los nombres de las partidas. La vinculación genealógica entre registros debe confirmarse para evitar unir homónimos por error.</span></div>
    {people.length ? <div className="people-grid">{people.map(p=><button className="person-card" key={p.key} onClick={()=>onOpen(p.record)}><span className="person-monogram">{p.name.slice(0,1).toUpperCase()}</span><span className="person-card-content"><strong>{p.name}</strong><small>{p.role} · {TYPE_LABELS[p.record.type] || 'Otro'}</small><small>{p.record.parish || 'Parroquia sin indicar'} {p.date ? `· ${dateLabel(p.date)}` : ''}</small></span><ChevronRight size={16}/></button>)}</div> : <EmptyState icon={<Users size={24}/>} title="No se encontraron personas" text="Las personas aparecerán automáticamente al indexar partidas." />}
  </section>;
}

function PlacesPage({catalog,onChanged,notify}:{catalog:ArchiveCatalog[];onChanged:()=>Promise<void>;notify:(n:{kind:'success'|'error'|'info';text:string})=>void}) {
  const [formKind,setFormKind] = useState('parish');
  const [filterKind,setFilterKind] = useState('all');
  const [name,setName] = useState('');
  const [parent,setParent] = useState('');
  const [filter,setFilter] = useState('');
  const entries = catalog.filter(c=>(filterKind==='all'||c.kind===filterKind)&&`${c.name} ${c.parent}`.toLowerCase().includes(filter.toLowerCase()));
  const add = async () => { if(!name.trim()){notify({kind:'error',text:'Escribe el nombre del lugar.'});return;} try{await window.archiveApi.addCatalog({kind:formKind,name,parent});setName('');setParent('');await onChanged();notify({kind:'success',text:'Lugar añadido al catálogo.'});}catch(e){notify({kind:'error',text:String(e)});} };
  return <div className="places-layout"><section className="panel place-form-panel"><div className="panel-heading"><div><h3>Añadir al catálogo</h3><p>No hay que preconfigurar los lugares.</p></div><span className="place-form-icon"><MapPin size={19}/></span></div><div className="catalog-form"><Field label="Tipo de lugar"><select value={formKind} onChange={e=>setFormKind(e.target.value)}>{Object.entries(CATALOG_LABELS).map(([v,l])=><option key={v} value={v}>{l}</option>)}</select></Field><Field label="Nombre" required><input value={name} onChange={e=>setName(e.target.value)} onKeyDown={e=>{if(e.key==='Enter')void add();}} placeholder={formKind==='parish'?'Ej. Parroquia de San José':'Nombre del lugar'}/></Field><Field label="Relación o ubicación (opcional)"><input value={parent} onChange={e=>setParent(e.target.value)} placeholder="Municipio, provincia o localidad"/></Field><button className="primary-button full-width" onClick={()=>void add()}><Plus size={16}/> Añadir lugar</button><p className="inline-help"><Sparkles size={14}/> También se guardan automáticamente los lugares que uses en las partidas.</p></div></section>
    <section className="panel catalog-list-panel"><div className="panel-heading"><div><h3>Catálogo de lugares</h3><p>{catalog.length} entradas guardadas</p></div><div className="catalog-search"><Search size={15}/><input placeholder="Filtrar catálogo…" value={filter} onChange={e=>setFilter(e.target.value)}/></div></div><div className="catalog-tabs"><button className={filterKind==='all'?'selected':''} onClick={()=>setFilterKind('all')}>Todos</button>{Object.entries(CATALOG_LABELS).map(([v,l])=><button key={v} className={filterKind===v?'selected':''} onClick={()=>setFilterKind(v)}>{l}</button>)}</div>
      {entries.length ? <div className="catalog-list">{entries.map(entry=><div className="catalog-row" key={entry.id}><span className={`catalog-kind ${entry.kind}`}><MapPin size={16}/></span><span className="catalog-row-info"><strong>{entry.name}</strong><small>{CATALOG_LABELS[entry.kind]}{entry.parent ? ` · ${entry.parent}` : ''}</small></span></div>)}</div> : <EmptyMini text="No hay lugares de este tipo todavía. Puedes añadir el primero arriba."/>}
    </section></div>;
}

function CertificatesPage({records,notify,initialSelected}:{records:ArchiveRecord[];notify:(n:{kind:'success'|'error'|'info';text:string})=>void;initialSelected?:number|''}) {
  const [selected,setSelected] = useState<number | ''>(initialSelected || '');
  const [heading,setHeading] = useState('ARCHIVO SACRAMENTAL Y GENEALÓGICO');
  const [institution,setInstitution] = useState('');
  const [signedBy,setSignedBy] = useState('');
  const [includeTranscription,setIncludeTranscription] = useState(true);
  const record = records.find(r=>r.id===Number(selected));
  const makeLines = () => {
    if(!record) return [];
    const lines = [
      `Tipo de registro: ${TYPE_LABELS[record.type] || record.type}`,
      `Nombre: ${fullName(record)}`,
      ...(record.type==='matrimonio' && (record.second_name || record.second_surnames) ? [`Segundo contrayente: ${[record.second_name,record.second_surnames].filter(Boolean).join(' ')}`] : []),
      ...(record.birth_date ? [`Fecha de nacimiento: ${dateLabel(record.birth_date)}`] : []),
      ...(record.event_date ? [`Fecha del acto: ${dateLabel(record.event_date)}`] : []),
      ...(record.burial_date ? [`Fecha de entierro: ${dateLabel(record.burial_date)}`] : []),
      ...(record.age ? [`Edad indicada: ${record.age}`] : []),
      ...(record.father_name ? [`Padre: ${record.father_name}${record.father_nature ? ` · naturaleza: ${record.father_nature}` : ''}`] : []),
      ...(record.mother_name ? [`Madre: ${record.mother_name}${record.mother_nature ? ` · naturaleza: ${record.mother_nature}` : ''}`] : []),
      ...(record.paternal_grandfather_name ? [`Abuelo paterno: ${record.paternal_grandfather_name}`] : []),
      ...(record.paternal_grandmother_name ? [`Abuela paterna: ${record.paternal_grandmother_name}`] : []),
      ...(record.paternal_grandparents_nature ? [`Naturaleza de abuelos paternos: ${record.paternal_grandparents_nature}`] : []),
      ...(record.maternal_grandfather_name ? [`Abuelo materno: ${record.maternal_grandfather_name}`] : []),
      ...(record.maternal_grandmother_name ? [`Abuela materna: ${record.maternal_grandmother_name}`] : []),
      ...(record.maternal_grandparents_nature ? [`Naturaleza de abuelos maternos: ${record.maternal_grandparents_nature}`] : []),
      ...(record.second_father_name ? [`Padre del segundo contrayente: ${record.second_father_name}${record.second_father_nature ? ` · naturaleza: ${record.second_father_nature}` : ''}`] : []),
      ...(record.second_mother_name ? [`Madre del segundo contrayente: ${record.second_mother_name}${record.second_mother_nature ? ` · naturaleza: ${record.second_mother_nature}` : ''}`] : []),
      ...(record.priest ? [`Presbítero / celebrante: ${record.priest}`] : []),
      ...(record.spouse_name ? [`Cónyuge: ${record.spouse_name}`] : []),
      `Parroquia: ${record.parish || 'No indicada'}`,
      `Localidad: ${[record.city,record.municipality,record.province,record.country].filter(Boolean).join(', ') || 'No indicada'}`,
      `Referencia: ${reference(record)}`
    ];
    return lines;
  };
  const exportPdf = () => {
    if(!record) return;
    const pdf = new jsPDF({unit:'mm',format:'a4'}); const w=210; const margin=22;
    pdf.setFillColor(23,42,58); pdf.rect(0,0,w,12,'F');
    pdf.setDrawColor(181,145,75); pdf.setLineWidth(0.8); pdf.rect(12,18,w-24,261);
    pdf.setTextColor(23,42,58); pdf.setFont('times','bold'); pdf.setFontSize(15); pdf.text(heading || 'ARCHIVO DOCUMENTAL',w/2,35,{align:'center',maxWidth:w-44});
    if(institution){pdf.setFont('times','normal');pdf.setFontSize(10);pdf.text(institution,w/2,42,{align:'center',maxWidth:w-44});}
    pdf.setDrawColor(181,145,75);pdf.line(64,48,146,48);pdf.setFontSize(18);pdf.setFont('times','bold');pdf.text('CERTIFICACIÓN / EXTRACTO',w/2,61,{align:'center'});
    pdf.setFont('times','normal');pdf.setFontSize(11);pdf.setTextColor(50,56,61);let y=78;
    const intro='Se hace constar que, según la transcripción y referencia documental conservadas en este archivo, obra el siguiente registro:';
    const introLines=pdf.splitTextToSize(intro,w-margin*2);pdf.text(introLines,margin,y);y+=introLines.length*6+8;
    for(const line of makeLines()){const wrapped=pdf.splitTextToSize(line,w-margin*2);pdf.text(wrapped,margin,y);y+=wrapped.length*6+2; if(y>220)break;}
    if(includeTranscription && record.transcription){y+=8;pdf.setFont('times','bold');pdf.text('Transcripción conservada',margin,y);y+=6;pdf.setFont('times','italic');const trans=pdf.splitTextToSize(record.transcription,w-margin*2);for(const chunk of trans){if(y>244)break;pdf.text(chunk,margin,y);y+=5;}}
    pdf.setFont('times','normal');pdf.setFontSize(9);pdf.setTextColor(100,100,100);pdf.text(`Documento generado el ${new Date().toLocaleDateString('es-ES')} · Registro interno n.º ${record.id}`,w/2,267,{align:'center'});
    if(signedBy){pdf.setTextColor(50,56,61);pdf.setFontSize(10);pdf.text(signedBy,w/2,250,{align:'center'});pdf.line(w/2-30,253,w/2+30,253);}
    pdf.save(`Certificacion-${record.id}-${(fullName(record).replace(/[^a-z0-9]+/gi,'-')||'registro')}.pdf`);
    notify({kind:'success',text:'Certificación PDF generada. Revisa el contenido antes de utilizarla oficialmente.'});
  };
  const exportJpg = () => {
    if(!record) return;
    const canvas=document.createElement('canvas');canvas.width=1240;canvas.height=1754;const ctx=canvas.getContext('2d');if(!ctx)return;
    ctx.fillStyle='#f8f6f0';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.fillStyle='#172a3a';ctx.fillRect(0,0,canvas.width,46);ctx.strokeStyle='#b5914b';ctx.lineWidth=5;ctx.strokeRect(55,72,1130,1605);
    ctx.textAlign='center';ctx.fillStyle='#172a3a';ctx.font='bold 31px Georgia';ctx.fillText((heading||'ARCHIVO DOCUMENTAL').toUpperCase(),620,145,1000);
    if(institution){ctx.font='23px Georgia';ctx.fillText(institution,620,190,1000);}ctx.strokeStyle='#b5914b';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(350,225);ctx.lineTo(890,225);ctx.stroke();ctx.font='bold 38px Georgia';ctx.fillText('CERTIFICACIÓN / EXTRACTO',620,292);
    ctx.textAlign='left';ctx.fillStyle='#32383d';ctx.font='24px Georgia';let y=365;const intro='Se hace constar que, según la transcripción y referencia documental conservadas en este archivo, obra el siguiente registro:';y=drawWrapped(ctx,intro,120,y,1000,37);
    y+=25;for(const line of makeLines()){y=drawWrapped(ctx,line,120,y,1000,36)+7;if(y>1370)break;}
    if(includeTranscription&&record.transcription&&y<1410){y+=15;ctx.font='bold 25px Georgia';ctx.fillText('Transcripción conservada',120,y);y+=42;ctx.font='italic 22px Georgia';y=drawWrapped(ctx,record.transcription,120,y,1000,32);}
    if(signedBy){ctx.textAlign='center';ctx.font='23px Georgia';ctx.fillText(signedBy,620,1570);ctx.beginPath();ctx.moveTo(430,1585);ctx.lineTo(810,1585);ctx.stroke();}
    ctx.textAlign='center';ctx.font='17px Georgia';ctx.fillStyle='#777';ctx.fillText(`Documento generado el ${new Date().toLocaleDateString('es-ES')} · Registro interno n.º ${record.id}`,620,1640);
    const a=document.createElement('a');a.href=canvas.toDataURL('image/jpeg',0.92);a.download=`Certificacion-${record.id}.jpg`;a.click();notify({kind:'success',text:'Imagen JPG generada. Revisa el contenido antes de utilizarla oficialmente.'});
  };
  return <div className="certificate-layout"><section className="panel certificate-settings"><div className="panel-heading"><div><h3>Preparar documento</h3><p>Selecciona una partida y personaliza el encabezado.</p></div><span className="place-form-icon"><FileCheck2 size={19}/></span></div><div className="catalog-form"><Field label="Partida del archivo" required><select value={selected} onChange={e=>setSelected(e.target.value?Number(e.target.value):'')}><option value="">Selecciona una partida…</option>{records.map(r=><option key={r.id} value={r.id}>{fullName(r)} · {TYPE_LABELS[r.type]||r.type} · {dateLabel(r.event_date)}</option>)}</select></Field><Field label="Encabezado"><input value={heading} onChange={e=>setHeading(e.target.value)} /></Field><Field label="Parroquia o institución emisora"><input value={institution} onChange={e=>setInstitution(e.target.value)} placeholder="Opcional"/></Field><Field label="Firma o cargo que aparecerá"><input value={signedBy} onChange={e=>setSignedBy(e.target.value)} placeholder="Opcional"/></Field><label className="checkbox-line"><input type="checkbox" checked={includeTranscription} onChange={e=>setIncludeTranscription(e.target.checked)}/><span>Incluir transcripción original</span></label><div className="cert-actions"><button className="primary-button" disabled={!record} onClick={exportPdf}><Download size={16}/> Generar PDF para imprimir</button><button className="secondary-button" disabled={!record} onClick={exportJpg}><ImageIcon size={16}/> Exportar JPG</button></div><div className="legal-note"><AlertCircle size={16}/><span>El documento generado es un extracto del archivo. Su validez oficial depende de la autorización y firma de la institución competente.</span></div></div></section>
    <section className="certificate-preview-wrap"><div className="preview-caption"><span><Eye size={15}/> VISTA PREVIA</span><span>A4 · Documento imprimible</span></div><div className="certificate-paper"><div className="paper-topline"/><div className="paper-inner"><div className="paper-heading">{heading || 'ARCHIVO DOCUMENTAL'}</div>{institution&&<div className="paper-institution">{institution}</div>}<div className="paper-rule"/><h3>CERTIFICACIÓN / EXTRACTO</h3>{record ? <><p className="paper-intro">Se hace constar que, según la transcripción y referencia documental conservadas en este archivo, obra el siguiente registro:</p><div className="paper-details">{makeLines().map((line,i)=><p key={i}>{line}</p>)}</div>{includeTranscription&&record.transcription&&<><h4>Transcripción conservada</h4><p className="paper-transcription">{record.transcription}</p></>}{signedBy&&<div className="paper-signature"><span>{signedBy}</span></div>}</> : <div className="paper-empty"><FileText size={33}/><strong>Tu documento aparecerá aquí</strong><span>Selecciona una partida en el panel de la izquierda.</span></div>}<div className="paper-footer">Archivo local · Generado el {new Date().toLocaleDateString('es-ES')}</div></div></div></section></div>;
}
function drawWrapped(ctx:CanvasRenderingContext2D,text:string,x:number,y:number,maxWidth:number,lineHeight:number){const words=text.split(/\s+/);let line='';for(const word of words){const test=line?`${line} ${word}`:word;if(ctx.measureText(test).width>maxWidth&&line){ctx.fillText(line,x,y);line=word;y+=lineHeight;}else line=test;}if(line){ctx.fillText(line,x,y);y+=lineHeight;}return y;}

function BackupPage({appInfo,notify}:{appInfo:{version:string;dataDir:string;attachmentDir:string;platform:string}|null;notify:(n:{kind:'success'|'error'|'info';text:string})=>void}) {
  const [busy,setBusy] = useState(false);
  const backup = async () => {setBusy(true);try{const result=await window.archiveApi.createBackup();if(result.canceled)return;if(result.ok)notify({kind:'success',text:`Copia de seguridad creada correctamente: ${result.path}`});}catch(e){notify({kind:'error',text:`No se pudo crear la copia: ${String(e)}`});}finally{setBusy(false);}};
  return <div className="backup-content"><div className="backup-hero"><div className="backup-hero-icon"><ShieldCheck size={30}/></div><div><div className="eyebrow">CONSERVACIÓN Y SEGURIDAD</div><h2>Tu trabajo, protegido.</h2><p>Una copia incluye la base de datos y las imágenes/documentos adjuntos. Guárdala en otra unidad o ubicación segura.</p></div></div><div className="backup-grid"><section className="panel backup-card"><div className="backup-card-icon gold"><Download size={21}/></div><h3>Crear copia de seguridad</h3><p>Genera un archivo ZIP que contiene la base de datos y la carpeta de adjuntos para conservar o trasladar tu archivo.</p><button className="primary-button" onClick={()=>void backup()} disabled={busy}><ShieldCheck size={16}/>{busy?'Creando copia…':'Crear copia ZIP'}</button></section><section className="panel backup-card"><div className="backup-card-icon blue"><FolderOpen size={21}/></div><h3>Ubicación de los datos</h3><p>Abre la carpeta local donde la aplicación guarda su base de datos y las imágenes originales.</p><button className="secondary-button" onClick={()=>void window.archiveApi.showDataFolder()}><FolderOpen size={16}/> Abrir carpeta</button></section></div><section className="panel backup-checklist"><div className="panel-heading"><div><h3>Buenas prácticas de conservación</h3><p>Recomendaciones para evitar pérdidas accidentales.</p></div><ShieldCheck size={20} className="panel-heading-icon"/></div><div className="checklist"><div><span><Check size={15}/></span><p><strong>Conserva al menos dos copias.</strong><small>Guarda una copia en otro dispositivo o almacenamiento independiente.</small></p></div><div><span><Check size={15}/></span><p><strong>Incluye las fotografías originales.</strong><small>La copia ZIP integra los adjuntos de las partidas guardadas.</small></p></div><div><span><Check size={15}/></span><p><strong>Comprueba las copias periódicamente.</strong><small>Una copia solo es útil si puede abrirse y restaurarse correctamente.</small></p></div></div></section><section className="data-location"><div><Settings2 size={18}/><span><strong>Información de la instalación</strong><small>Versión {appInfo?.version||'1.0.0'} · Base de datos local</small></span></div><div className="data-path">{appInfo?.dataDir||'Disponible al ejecutar la aplicación en Windows'}</div></section></div>;
}

function TrashModal({items,onClose,onRestore}:{items:ArchiveRecord[];onClose:()=>void;onRestore:(r:ArchiveRecord)=>void}) { return <div className="modal-scrim" onMouseDown={e=>{if(e.target===e.currentTarget)onClose();}}><section className="trash-modal"><header><div><div className="eyebrow">RECUPERACIÓN</div><h2>Papelera de partidas</h2><p>Las partidas enviadas aquí no se borran definitivamente.</p></div><button className="icon-button" onClick={onClose}><X size={18}/></button></header>{items.length?<div className="trash-list">{items.map(r=><div className="trash-row" key={r.id}><span><strong>{fullName(r)}</strong><small>{TYPE_LABELS[r.type]||r.type} · {r.parish||'Sin parroquia'} · {dateLabel(r.event_date)}</small></span><button className="secondary-button small" onClick={()=>onRestore(r)}><RotateCcw size={14}/> Restaurar</button></div>)}</div>:<EmptyState icon={<Trash2 size={24}/>} title="La papelera está vacía" text="Las partidas que envíes a la papelera aparecerán aquí."/>}<footer><button className="quiet-button" onClick={onClose}>Cerrar</button></footer></section></div>; }
